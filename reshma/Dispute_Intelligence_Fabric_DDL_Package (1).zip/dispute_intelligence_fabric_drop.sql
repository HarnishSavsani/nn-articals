-- DESTRUCTIVE: drops the complete Dispute Intelligence Fabric schema.
DROP SCHEMA IF EXISTS dispute CASCADE;
