-- Dispute Intelligence Fabric
-- PostgreSQL / Supabase-compatible enterprise physical data model
-- Target: PostgreSQL 16+
-- Generated as an ERwin-ready baseline. Validate naming, retention, PCI scope,
-- jurisdictional rules, and organizational standards before production use.

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS vector;

CREATE SCHEMA IF NOT EXISTS dispute;
SET search_path TO dispute, public;

-- ============================================================
-- 1. REFERENCE / CODE TABLES
-- ============================================================

CREATE TABLE party_type_code (
    party_type_code        varchar(30) PRIMARY KEY,
    description            varchar(200) NOT NULL,
    active_ind             boolean NOT NULL DEFAULT true
);

CREATE TABLE case_state_code (
    case_state_code        varchar(40) PRIMARY KEY,
    description            varchar(200) NOT NULL,
    terminal_ind           boolean NOT NULL DEFAULT false,
    active_ind             boolean NOT NULL DEFAULT true
);

CREATE TABLE processing_side_code (
    processing_side_code   varchar(20) PRIMARY KEY,
    description            varchar(200) NOT NULL,
    active_ind             boolean NOT NULL DEFAULT true
);

CREATE TABLE evidence_type_code (
    evidence_type_code     varchar(50) PRIMARY KEY,
    description            varchar(200) NOT NULL,
    default_classification varchar(30),
    active_ind             boolean NOT NULL DEFAULT true
);

CREATE TABLE relationship_type_code (
    relationship_type_code varchar(30) PRIMARY KEY,
    description            varchar(200) NOT NULL,
    active_ind             boolean NOT NULL DEFAULT true
);

CREATE TABLE status_code (
    status_code            varchar(30) PRIMARY KEY,
    status_group           varchar(30) NOT NULL,
    description            varchar(200) NOT NULL,
    terminal_ind           boolean NOT NULL DEFAULT false,
    active_ind             boolean NOT NULL DEFAULT true
);

INSERT INTO party_type_code VALUES
('customer','Cardholder or customer',true),
('merchant','Merchant',true),
('issuer','Issuing institution',true),
('acquirer','Acquiring institution or processor',true),
('network','Card network or scheme',true),
('courier','Delivery or logistics provider',true),
('employee','Internal investigator, specialist, approver, or auditor',true),
('external_partner','Other external party',true)
ON CONFLICT DO NOTHING;

INSERT INTO case_state_code VALUES
('raised','Dispute recorded',false,true),
('gathering_evidence','Evidence collection in progress',false,true),
('reconstructing','Disputed event reconstruction in progress',false,true),
('comparing','Narrative comparison in progress',false,true),
('awaiting_evidence','Waiting for external or human evidence',false,true),
('interpretation_ready','AI-supported interpretation ready for review',false,true),
('specialist_review','Specialist review in progress',false,true),
('approval_pending','Consequential action awaiting approval',false,true),
('resolution_in_progress','Approved resolution action in progress',false,true),
('suspended','Case suspended for recovery or exception',false,true),
('closed','Case closed by authorized human decision',true,true)
ON CONFLICT DO NOTHING;

INSERT INTO processing_side_code VALUES
('issuer','Issuer or cardholder side',true),
('acquirer','Acquirer or processor side',true),
('merchant','Merchant-side representment',true),
('network','Network or scheme processing',true)
ON CONFLICT DO NOTHING;

INSERT INTO evidence_type_code VALUES
('customer_statement','Customer narrative','confidential',true),
('merchant_statement','Merchant narrative','confidential',true),
('transaction_event','Authorization, clearing, or posting event','restricted',true),
('authentication_event','Authentication or 3DS evidence','restricted',true),
('receipt','Receipt or proof of purchase','confidential',true),
('invoice','Invoice','confidential',true),
('delivery_proof','Delivery or service evidence','confidential',true),
('refund_record','Refund evidence','confidential',true),
('cancellation_record','Cancellation evidence','confidential',true),
('correspondence','Customer, merchant, or operations correspondence','confidential',true),
('scheme_message','Card network message','restricted',true),
('reconciliation_record','Reconciliation or settlement record','restricted',true),
('system_log','System-generated log or trace','restricted',true),
('other','Other governed evidence','confidential',true)
ON CONFLICT DO NOTHING;

INSERT INTO relationship_type_code VALUES
('SUPPORTS','Source strengthens target assertion or hypothesis',true),
('CONTRADICTS','Source conflicts with target in compatible scope and time',true),
('CORROBORATES','Source independently confirms target',true),
('SUPERSEDES','Source replaces target as the effective version',true),
('DUPLICATES','Source represents the same logical item as target',true),
('DERIVED_FROM','Source was derived from target',true),
('RELATES_TO','Source is otherwise related to target',true),
('INVALIDATES','Source invalidates target for current use',true)
ON CONFLICT DO NOTHING;

INSERT INTO status_code VALUES
('pending','approval','Pending action or approval',false,true),
('approved','approval','Approved',true,true),
('rejected','approval','Rejected',true,true),
('paused','approval','Paused due to material change or control',false,true),
('withdrawn','approval','Withdrawn',true,true),
('expired','approval','Expired',true,true),
('prepared','action','Prepared but not submitted',false,true),
('submitted','action','Submitted to external system',false,true),
('retry_pending','action','Retry scheduled',false,true),
('ambiguous','action','External outcome unresolved',false,true),
('succeeded','action','Completed successfully',true,true),
('failed','action','Completed unsuccessfully',true,true),
('cancelled','action','Cancelled',true,true),
('compensated','action','Compensating action completed',true,true),
('reconciled','action','Externally and internally reconciled',true,true),
('open','generic','Open',false,true),
('closed','generic','Closed',true,true),
('stale','generic','Invalidated by changed dependency',false,true)
ON CONFLICT DO NOTHING;

-- ============================================================
-- 2. PARTIES, CASES, AND TRANSACTIONS
-- ============================================================

CREATE TABLE parties (
    party_id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    party_type_code        varchar(30) NOT NULL REFERENCES party_type_code(party_type_code),
    display_name           varchar(200) NOT NULL,
    external_reference     varchar(120),
    status_code            varchar(20) NOT NULL DEFAULT 'active',
    created_at             timestamptz NOT NULL DEFAULT now(),
    updated_at             timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_parties_external UNIQUE (party_type_code, external_reference)
);

CREATE TABLE cases (
    case_id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_reference         varchar(40) NOT NULL UNIQUE,
    title                  varchar(200) NOT NULL,
    narrative              text NOT NULL,
    case_state_code        varchar(40) NOT NULL DEFAULT 'raised'
                              REFERENCES case_state_code(case_state_code),
    processing_side_code   varchar(20) NOT NULL DEFAULT 'issuer'
                              REFERENCES processing_side_code(processing_side_code),
    amount                 numeric(18,2) NOT NULL DEFAULT 0 CHECK (amount >= 0),
    currency_code          varchar(3) NOT NULL,
    customer_name          varchar(120),
    merchant_name          varchar(120),
    final_liability_code   varchar(32),
    jurisdiction_code      varchar(20),
    created_at             timestamptz NOT NULL DEFAULT now(),
    updated_at             timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_cases_currency_upper CHECK (currency_code = upper(currency_code)),
    CONSTRAINT ck_cases_final_liability CHECK (
        final_liability_code IS NULL OR
        final_liability_code IN ('customer','merchant','shared','no_liability')
    )
);

CREATE TABLE case_parties (
    case_party_id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id                uuid NOT NULL REFERENCES cases(case_id) ON DELETE RESTRICT,
    party_id               uuid NOT NULL REFERENCES parties(party_id) ON DELETE RESTRICT,
    role_code              varchar(30) NOT NULL,
    effective_from         timestamptz NOT NULL DEFAULT now(),
    effective_to           timestamptz,
    CONSTRAINT uq_case_parties UNIQUE (case_id, party_id, role_code, effective_from),
    CONSTRAINT ck_case_party_dates CHECK (effective_to IS NULL OR effective_to >= effective_from)
);

CREATE TABLE transactions (
    transaction_id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    external_transaction_ref varchar(120) NOT NULL UNIQUE,
    merchant_party_id      uuid REFERENCES parties(party_id) ON DELETE RESTRICT,
    authorization_code     varchar(40),
    tokenized_account_ref  varchar(160),
    transaction_amount     numeric(18,2) NOT NULL CHECK (transaction_amount >= 0),
    currency_code          varchar(3) NOT NULL,
    transaction_at         timestamptz NOT NULL,
    posted_at              timestamptz,
    transaction_status_code varchar(30),
    created_at             timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_transactions_currency_upper CHECK (currency_code = upper(currency_code))
);

CREATE TABLE case_transactions (
    case_id                uuid NOT NULL REFERENCES cases(case_id) ON DELETE RESTRICT,
    transaction_id         uuid NOT NULL REFERENCES transactions(transaction_id) ON DELETE RESTRICT,
    relationship_type_code varchar(30) NOT NULL DEFAULT 'RELATES_TO'
                              REFERENCES relationship_type_code(relationship_type_code),
    disputed_amount        numeric(18,2) CHECK (disputed_amount IS NULL OR disputed_amount >= 0),
    PRIMARY KEY (case_id, transaction_id)
);

-- ============================================================
-- 3. EVIDENCE, ASSERTIONS, AND EVENTS
-- ============================================================

CREATE TABLE evidence_items (
    evidence_item_id       uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id                uuid NOT NULL REFERENCES cases(case_id) ON DELETE RESTRICT,
    evidence_type_code     varchar(50) NOT NULL REFERENCES evidence_type_code(evidence_type_code),
    subject_type_code      varchar(30),
    subject_id             uuid,
    classification_code    varchar(30) NOT NULL DEFAULT 'confidential',
    status_code            varchar(30) NOT NULL DEFAULT 'open',
    created_at             timestamptz NOT NULL DEFAULT now(),
    updated_at             timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE evidence_versions (
    evidence_version_id    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    evidence_item_id       uuid NOT NULL REFERENCES evidence_items(evidence_item_id) ON DELETE RESTRICT,
    version_no             integer NOT NULL CHECK (version_no > 0),
    supersedes_version_id  uuid REFERENCES evidence_versions(evidence_version_id) ON DELETE RESTRICT,
    evidence_source_code   varchar(50) NOT NULL,
    content_text           text,
    object_path            text,
    sha256_hash            varchar(64),
    valid_at               timestamptz NOT NULL,
    recorded_at            timestamptz NOT NULL DEFAULT now(),
    extractor_version      varchar(80),
    quality_payload_json   jsonb NOT NULL DEFAULT '{}'::jsonb,
    UNIQUE (evidence_item_id, version_no),
    CONSTRAINT ck_evidence_content CHECK (content_text IS NOT NULL OR object_path IS NOT NULL),
    CONSTRAINT ck_evidence_sha256 CHECK (sha256_hash IS NULL OR sha256_hash ~ '^[0-9a-fA-F]{64}$')
);

CREATE TABLE assertions (
    assertion_id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id                uuid NOT NULL REFERENCES cases(case_id) ON DELETE RESTRICT,
    evidence_version_id    uuid NOT NULL REFERENCES evidence_versions(evidence_version_id) ON DELETE RESTRICT,
    subject_type_code      varchar(30) NOT NULL,
    subject_id             uuid,
    predicate_code         varchar(80) NOT NULL,
    assertion_value_json   jsonb NOT NULL,
    valid_from             timestamptz,
    valid_to               timestamptz,
    recorded_at            timestamptz NOT NULL DEFAULT now(),
    assertion_status_code  varchar(30) NOT NULL DEFAULT 'open',
    extraction_confidence  numeric(5,4) CHECK (extraction_confidence BETWEEN 0 AND 1),
    CONSTRAINT ck_assertion_dates CHECK (valid_to IS NULL OR valid_from IS NULL OR valid_to >= valid_from)
);

CREATE TABLE case_events (
    case_event_id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id                uuid NOT NULL REFERENCES cases(case_id) ON DELETE RESTRICT,
    event_type_code        varchar(50) NOT NULL,
    event_at               timestamptz NOT NULL,
    recorded_at            timestamptz NOT NULL DEFAULT now(),
    evidence_version_id    uuid REFERENCES evidence_versions(evidence_version_id) ON DELETE RESTRICT,
    actor_party_id         uuid REFERENCES parties(party_id) ON DELETE RESTRICT,
    event_payload_json     jsonb NOT NULL DEFAULT '{}'::jsonb,
    certainty_code         varchar(20) NOT NULL DEFAULT 'observed'
);

-- Forward declaration is not needed; agent_outputs is created before assertion_relationships.

-- ============================================================
-- 4. AI AGENTS, OUTPUTS, AND EVIDENCE LINKS
-- ============================================================

CREATE TABLE agent_definitions (
    agent_id               varchar(10) PRIMARY KEY,
    agent_name             varchar(120) NOT NULL UNIQUE,
    output_type_code       varchar(50) NOT NULL,
    description            text NOT NULL,
    final_liability_allowed_ind boolean NOT NULL DEFAULT false,
    external_action_allowed_ind boolean NOT NULL DEFAULT false,
    active_ind             boolean NOT NULL DEFAULT true,
    created_at             timestamptz NOT NULL DEFAULT now()
);

INSERT INTO agent_definitions(agent_id,agent_name,output_type_code,description) VALUES
('A01','Intake Structuring Agent','atomic_claims','Structures dispute narratives into candidate atomic claims'),
('A02','Document Classification Agent','classification','Classifies evidence type, language, and sensitivity'),
('A03','Evidence Extraction Agent','assertions','Extracts typed fields and source passages'),
('A04','Provenance and Integrity Agent','provenance','Validates source metadata, hash, version, and lineage'),
('A05','Entity Resolution Agent','entity_links','Links evidence to cases, transactions, parties, devices, or shipments'),
('A06','Duplicate and Similarity Agent','duplicates','Detects exact and semantic duplicates'),
('A07','Evidence Quality Agent','quality','Assesses completeness, freshness, consistency, and corroboration'),
('A08','Event Reconstruction Agent','timeline','Creates bitemporal event timelines and alternatives'),
('A09','Contradiction Detection Agent','contradictions','Classifies conflicts between comparable assertions'),
('A10','Evidence Gap Agent','gaps','Identifies decision-relevant missing information'),
('A11','Hypothesis Management Agent','hypotheses','Maintains competing interpretations and uncertainty'),
('A12','Material Change and Impact Agent','impact','Determines impacts of new or corrected evidence'),
('A13','Next-Best-Evidence Agent','evidence_recommendations','Ranks allowable evidence requests'),
('A14','Next-Best-Action Agent','action_recommendations','Ranks policy-permitted case actions'),
('A15','Reviewer Pack and Explanation Agent','review_pack','Creates specialist review packs and change explanations'),
('A16','Correspondence Drafting Agent','draft','Drafts controlled customer or merchant communications'),
('A17','AI Assurance and Monitoring Agent','assurance','Monitors quality, drift, security signals, and cost')
ON CONFLICT DO NOTHING;

CREATE TABLE agent_runs (
    agent_run_id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id                uuid NOT NULL REFERENCES cases(case_id) ON DELETE RESTRICT,
    agent_id               varchar(10) NOT NULL REFERENCES agent_definitions(agent_id),
    model_provider         varchar(80),
    model_name             varchar(120),
    model_version          varchar(80),
    prompt_version         varchar(80),
    policy_version         varchar(80),
    status_code            varchar(30) NOT NULL DEFAULT 'submitted',
    started_at             timestamptz NOT NULL DEFAULT now(),
    completed_at           timestamptz,
    token_input_count      integer CHECK (token_input_count IS NULL OR token_input_count >= 0),
    token_output_count     integer CHECK (token_output_count IS NULL OR token_output_count >= 0),
    cost_amount            numeric(18,6) CHECK (cost_amount IS NULL OR cost_amount >= 0),
    error_detail           text,
    CONSTRAINT ck_agent_run_dates CHECK (completed_at IS NULL OR completed_at >= started_at)
);

CREATE TABLE agent_outputs (
    agent_output_id        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id                uuid NOT NULL REFERENCES cases(case_id) ON DELETE RESTRICT,
    agent_run_id           uuid NOT NULL REFERENCES agent_runs(agent_run_id) ON DELETE RESTRICT,
    agent_id               varchar(10) NOT NULL REFERENCES agent_definitions(agent_id),
    output_type_code       varchar(50) NOT NULL,
    output_payload_json    jsonb NOT NULL DEFAULT '{}'::jsonb,
    confidence             double precision NOT NULL DEFAULT 0 CHECK (confidence BETWEEN 0 AND 1),
    stale_ind              boolean NOT NULL DEFAULT false,
    stale_reason           text,
    created_at             timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE agent_output_evidence (
    agent_output_id        uuid NOT NULL REFERENCES agent_outputs(agent_output_id) ON DELETE CASCADE,
    evidence_version_id    uuid NOT NULL REFERENCES evidence_versions(evidence_version_id) ON DELETE RESTRICT,
    usage_type_code        varchar(30) NOT NULL DEFAULT 'input',
    PRIMARY KEY (agent_output_id, evidence_version_id)
);

CREATE TABLE assertion_relationships (
    assertion_relationship_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    source_assertion_id     uuid NOT NULL REFERENCES assertions(assertion_id) ON DELETE RESTRICT,
    target_assertion_id     uuid NOT NULL REFERENCES assertions(assertion_id) ON DELETE RESTRICT,
    relationship_type_code  varchar(30) NOT NULL REFERENCES relationship_type_code(relationship_type_code),
    severity_code           varchar(20),
    created_by_agent_output_id uuid REFERENCES agent_outputs(agent_output_id) ON DELETE RESTRICT,
    created_at              timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_assertion_relationship_self CHECK (source_assertion_id <> target_assertion_id),
    CONSTRAINT uq_assertion_relationship UNIQUE (source_assertion_id,target_assertion_id,relationship_type_code)
);

-- ============================================================
-- 5. HYPOTHESES, CONCLUSIONS, AND DEPENDENCIES
-- ============================================================

CREATE TABLE hypotheses (
    hypothesis_id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id                uuid NOT NULL REFERENCES cases(case_id) ON DELETE RESTRICT,
    hypothesis_type_code   varchar(50) NOT NULL,
    statement_text         text NOT NULL,
    status_code            varchar(30) NOT NULL DEFAULT 'open',
    confidence_band_code   varchar(20),
    agent_output_id        uuid REFERENCES agent_outputs(agent_output_id) ON DELETE RESTRICT,
    stale_ind              boolean NOT NULL DEFAULT false,
    created_at             timestamptz NOT NULL DEFAULT now(),
    updated_at             timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE hypothesis_assertions (
    hypothesis_id          uuid NOT NULL REFERENCES hypotheses(hypothesis_id) ON DELETE CASCADE,
    assertion_id           uuid NOT NULL REFERENCES assertions(assertion_id) ON DELETE RESTRICT,
    effect_code            varchar(20) NOT NULL CHECK (effect_code IN ('supports','weakens','neutral','invalidates')),
    weight                 numeric(7,4),
    PRIMARY KEY (hypothesis_id, assertion_id)
);

CREATE TABLE policy_versions (
    policy_version_id      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_code            varchar(80) NOT NULL,
    version_no             varchar(40) NOT NULL,
    jurisdiction_code      varchar(20),
    effective_from         timestamptz NOT NULL,
    effective_to           timestamptz,
    policy_payload_json    jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at             timestamptz NOT NULL DEFAULT now(),
    UNIQUE (policy_code, version_no),
    CONSTRAINT ck_policy_dates CHECK (effective_to IS NULL OR effective_to >= effective_from)
);

CREATE TABLE conclusions (
    conclusion_id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id                uuid NOT NULL REFERENCES cases(case_id) ON DELETE RESTRICT,
    conclusion_type_code   varchar(50) NOT NULL,
    conclusion_value_json  jsonb NOT NULL,
    validity_status_code   varchar(20) NOT NULL DEFAULT 'current',
    agent_output_id        uuid REFERENCES agent_outputs(agent_output_id) ON DELETE RESTRICT,
    policy_version_id      uuid REFERENCES policy_versions(policy_version_id) ON DELETE RESTRICT,
    stale_ind              boolean NOT NULL DEFAULT false,
    created_at             timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE artifact_dependencies (
    dependency_id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id                uuid NOT NULL REFERENCES cases(case_id) ON DELETE RESTRICT,
    source_artifact_type   varchar(30) NOT NULL,
    source_artifact_id     uuid NOT NULL,
    target_artifact_type   varchar(30) NOT NULL,
    target_artifact_id     uuid NOT NULL,
    dependency_type_code   varchar(30) NOT NULL,
    created_at             timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_artifact_dependency UNIQUE (
        case_id, source_artifact_type, source_artifact_id,
        target_artifact_type, target_artifact_id, dependency_type_code
    )
);

-- ============================================================
-- 6. TASKS, APPROVALS, HUMAN DECISIONS, AND ACTIONS
-- ============================================================

CREATE TABLE tasks (
    task_id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id                uuid NOT NULL REFERENCES cases(case_id) ON DELETE RESTRICT,
    task_type_code         varchar(50) NOT NULL,
    assigned_role_code     varchar(40),
    assigned_user_id       uuid REFERENCES parties(party_id) ON DELETE RESTRICT,
    status_code            varchar(30) NOT NULL DEFAULT 'open',
    due_at                 timestamptz,
    completed_at           timestamptz,
    workflow_reference     varchar(120),
    created_at             timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT ck_task_dates CHECK (completed_at IS NULL OR completed_at >= created_at)
);

CREATE TABLE approvals (
    approval_id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id                uuid NOT NULL REFERENCES cases(case_id) ON DELETE RESTRICT,
    action_type_code       varchar(80) NOT NULL,
    maker_user_id          uuid NOT NULL REFERENCES parties(party_id) ON DELETE RESTRICT,
    approver_user_id       uuid REFERENCES parties(party_id) ON DELETE RESTRICT,
    status_code            varchar(30) NOT NULL DEFAULT 'pending',
    rationale              text,
    created_at             timestamptz NOT NULL DEFAULT now(),
    decided_at             timestamptz,
    CONSTRAINT ck_approval_maker_checker CHECK (
        approver_user_id IS NULL OR maker_user_id <> approver_user_id
    ),
    CONSTRAINT ck_approval_dates CHECK (decided_at IS NULL OR decided_at >= created_at)
);

CREATE TABLE approval_evidence_snapshot (
    approval_id            uuid NOT NULL REFERENCES approvals(approval_id) ON DELETE CASCADE,
    evidence_version_id    uuid NOT NULL REFERENCES evidence_versions(evidence_version_id) ON DELETE RESTRICT,
    included_at            timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (approval_id, evidence_version_id)
);

CREATE TABLE actions (
    action_id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id                uuid NOT NULL REFERENCES cases(case_id) ON DELETE RESTRICT,
    approval_id            uuid REFERENCES approvals(approval_id) ON DELETE RESTRICT,
    action_type_code       varchar(80) NOT NULL,
    idempotency_key        varchar(160) NOT NULL UNIQUE,
    status_code            varchar(30) NOT NULL DEFAULT 'prepared',
    external_reference     varchar(120),
    result_payload_json    jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at             timestamptz NOT NULL DEFAULT now(),
    updated_at             timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE action_attempts (
    action_attempt_id      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    action_id              uuid NOT NULL REFERENCES actions(action_id) ON DELETE CASCADE,
    attempt_number         integer NOT NULL CHECK (attempt_number > 0),
    request_payload_hash   varchar(64),
    started_at             timestamptz NOT NULL DEFAULT now(),
    completed_at           timestamptz,
    outcome_code           varchar(30),
    external_reference     varchar(120),
    response_payload_json  jsonb NOT NULL DEFAULT '{}'::jsonb,
    UNIQUE (action_id, attempt_number),
    CONSTRAINT ck_action_attempt_dates CHECK (completed_at IS NULL OR completed_at >= started_at)
);

CREATE TABLE human_decisions (
    human_decision_id      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id                uuid NOT NULL REFERENCES cases(case_id) ON DELETE RESTRICT,
    decision_type_code     varchar(50) NOT NULL,
    decision_value_code    varchar(50) NOT NULL,
    decided_by_user_id     uuid NOT NULL REFERENCES parties(party_id) ON DELETE RESTRICT,
    approval_id            uuid REFERENCES approvals(approval_id) ON DELETE RESTRICT,
    rationale              text NOT NULL,
    decided_at             timestamptz NOT NULL DEFAULT now()
);

-- ============================================================
-- 7. AUDIT, INTEGRATION, OPERATIONS, AND AI EVALUATION
-- ============================================================

CREATE TABLE audit_events (
    audit_event_id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id                uuid REFERENCES cases(case_id) ON DELETE SET NULL,
    actor_type_code        varchar(30) NOT NULL,
    actor_id               varchar(120) NOT NULL,
    event_type_code        varchar(80) NOT NULL,
    object_type_code       varchar(50),
    object_id              uuid,
    correlation_id         uuid NOT NULL DEFAULT gen_random_uuid(),
    causation_id           uuid,
    details_json           jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at             timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE integration_events (
    integration_event_id   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id                uuid REFERENCES cases(case_id) ON DELETE SET NULL,
    event_type_code        varchar(80) NOT NULL,
    schema_version         varchar(30) NOT NULL,
    source_system_code     varchar(50) NOT NULL,
    correlation_id         uuid NOT NULL,
    causation_id           uuid,
    idempotency_key        varchar(160),
    payload_json           jsonb NOT NULL,
    occurred_at            timestamptz NOT NULL,
    recorded_at            timestamptz NOT NULL DEFAULT now(),
    processing_status_code varchar(30) NOT NULL DEFAULT 'pending',
    UNIQUE (source_system_code, idempotency_key)
);

CREATE TABLE dead_letter_events (
    dead_letter_event_id   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    integration_event_id   uuid REFERENCES integration_events(integration_event_id) ON DELETE RESTRICT,
    case_id                uuid REFERENCES cases(case_id) ON DELETE SET NULL,
    failure_code           varchar(50) NOT NULL,
    failure_detail         text NOT NULL,
    payload_json           jsonb NOT NULL,
    retry_count            integer NOT NULL DEFAULT 0 CHECK (retry_count >= 0),
    status_code            varchar(30) NOT NULL DEFAULT 'open',
    created_at             timestamptz NOT NULL DEFAULT now(),
    resolved_at            timestamptz
);

CREATE TABLE reconciliation_records (
    reconciliation_record_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    case_id                uuid NOT NULL REFERENCES cases(case_id) ON DELETE RESTRICT,
    action_id              uuid REFERENCES actions(action_id) ON DELETE RESTRICT,
    source_system_code     varchar(50) NOT NULL,
    internal_status_code   varchar(30),
    external_status_code   varchar(30),
    match_status_code      varchar(30) NOT NULL,
    details_json           jsonb NOT NULL DEFAULT '{}'::jsonb,
    reconciled_at          timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE model_evaluations (
    model_evaluation_id    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id               varchar(10) NOT NULL REFERENCES agent_definitions(agent_id),
    model_provider         varchar(80),
    model_name             varchar(120),
    model_version          varchar(80),
    evaluation_suite_code  varchar(80) NOT NULL,
    dataset_version        varchar(80) NOT NULL,
    metric_payload_json    jsonb NOT NULL,
    passed_ind             boolean NOT NULL,
    evaluated_at           timestamptz NOT NULL DEFAULT now(),
    approved_by_user_id    uuid REFERENCES parties(party_id) ON DELETE RESTRICT,
    approval_rationale     text
);

-- ============================================================
-- 8. INDEXES
-- ============================================================

CREATE INDEX ix_cases_state ON cases(case_state_code);
CREATE INDEX ix_cases_processing_side ON cases(processing_side_code);
CREATE INDEX ix_cases_created_at ON cases(created_at DESC);
CREATE INDEX ix_case_parties_case ON case_parties(case_id);
CREATE INDEX ix_case_parties_party ON case_parties(party_id);
CREATE INDEX ix_transactions_merchant ON transactions(merchant_party_id);
CREATE INDEX ix_case_transactions_transaction ON case_transactions(transaction_id);
CREATE INDEX ix_evidence_items_case ON evidence_items(case_id);
CREATE INDEX ix_evidence_items_type ON evidence_items(evidence_type_code);
CREATE INDEX ix_evidence_versions_item_time ON evidence_versions(evidence_item_id, recorded_at DESC);
CREATE INDEX ix_evidence_versions_supersedes ON evidence_versions(supersedes_version_id);
CREATE INDEX ix_assertions_case ON assertions(case_id);
CREATE INDEX ix_assertions_evidence ON assertions(evidence_version_id);
CREATE INDEX ix_assertions_predicate ON assertions(predicate_code);
CREATE INDEX ix_assertion_rel_source ON assertion_relationships(source_assertion_id);
CREATE INDEX ix_assertion_rel_target ON assertion_relationships(target_assertion_id);
CREATE INDEX ix_case_events_case_time ON case_events(case_id, event_at);
CREATE INDEX ix_agent_runs_case ON agent_runs(case_id, started_at DESC);
CREATE INDEX ix_agent_outputs_case ON agent_outputs(case_id, created_at DESC);
CREATE INDEX ix_agent_outputs_agent ON agent_outputs(agent_id, created_at DESC);
CREATE INDEX ix_agent_outputs_stale ON agent_outputs(case_id, stale_ind);
CREATE INDEX ix_hypotheses_case ON hypotheses(case_id);
CREATE INDEX ix_conclusions_case ON conclusions(case_id);
CREATE INDEX ix_dependencies_source ON artifact_dependencies(source_artifact_type, source_artifact_id);
CREATE INDEX ix_dependencies_target ON artifact_dependencies(target_artifact_type, target_artifact_id);
CREATE INDEX ix_tasks_case_status ON tasks(case_id, status_code);
CREATE INDEX ix_tasks_due ON tasks(due_at) WHERE completed_at IS NULL;
CREATE INDEX ix_approvals_case_status ON approvals(case_id, status_code);
CREATE INDEX ix_actions_case_status ON actions(case_id, status_code);
CREATE INDEX ix_action_attempts_action ON action_attempts(action_id, attempt_number);
CREATE INDEX ix_human_decisions_case ON human_decisions(case_id, decided_at DESC);
CREATE INDEX ix_audit_case_time ON audit_events(case_id, created_at);
CREATE INDEX ix_audit_correlation ON audit_events(correlation_id);
CREATE INDEX ix_integration_case_time ON integration_events(case_id, recorded_at);
CREATE INDEX ix_dead_letter_status ON dead_letter_events(status_code, created_at);
CREATE INDEX ix_reconciliation_case ON reconciliation_records(case_id, reconciled_at DESC);
CREATE INDEX ix_model_evaluations_agent ON model_evaluations(agent_id, evaluated_at DESC);

-- JSONB indexes where flexible payload search is expected.
CREATE INDEX ix_agent_output_payload_gin ON agent_outputs USING gin(output_payload_json);
CREATE INDEX ix_audit_details_gin ON audit_events USING gin(details_json);
CREATE INDEX ix_integration_payload_gin ON integration_events USING gin(payload_json);

-- ============================================================
-- 9. SUPPORTING TRIGGERS
-- ============================================================

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at := now();
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_cases_updated_at
BEFORE UPDATE ON cases
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_parties_updated_at
BEFORE UPDATE ON parties
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_evidence_items_updated_at
BEFORE UPDATE ON evidence_items
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_hypotheses_updated_at
BEFORE UPDATE ON hypotheses
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TRIGGER trg_actions_updated_at
BEFORE UPDATE ON actions
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Prevent mutation of immutable evidence versions after insert.
CREATE OR REPLACE FUNCTION prevent_evidence_version_update()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'evidence_versions is immutable; insert a new version instead';
END;
$$;

CREATE TRIGGER trg_evidence_versions_immutable_update
BEFORE UPDATE ON evidence_versions
FOR EACH ROW EXECUTE FUNCTION prevent_evidence_version_update();

CREATE TRIGGER trg_evidence_versions_immutable_delete
BEFORE DELETE ON evidence_versions
FOR EACH ROW EXECUTE FUNCTION prevent_evidence_version_update();

-- Ensure an action approval belongs to the same case.
CREATE OR REPLACE FUNCTION validate_action_approval_case()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
    approval_case uuid;
BEGIN
    IF NEW.approval_id IS NULL THEN
        RETURN NEW;
    END IF;
    SELECT case_id INTO approval_case FROM approvals WHERE approval_id = NEW.approval_id;
    IF approval_case IS DISTINCT FROM NEW.case_id THEN
        RAISE EXCEPTION 'Action case_id and approval case_id must match';
    END IF;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_actions_validate_approval_case
BEFORE INSERT OR UPDATE ON actions
FOR EACH ROW EXECUTE FUNCTION validate_action_approval_case();

-- ============================================================
-- 10. COMMENTS FOR ERWIN / DATA CATALOG
-- ============================================================

COMMENT ON SCHEMA dispute IS 'AI-native bilateral card dispute and evidence intelligence model';
COMMENT ON TABLE cases IS 'Root dispute case aggregate. Final liability remains human-owned.';
COMMENT ON TABLE evidence_items IS 'Stable logical evidence item';
COMMENT ON TABLE evidence_versions IS 'Immutable bitemporal evidence versions';
COMMENT ON TABLE assertions IS 'Atomic statements extracted from or entered against evidence';
COMMENT ON TABLE assertion_relationships IS 'Evidence graph relationships such as SUPPORTS and CONTRADICTS';
COMMENT ON TABLE agent_outputs IS 'Typed, evidence-grounded outputs from bounded AI agents';
COMMENT ON TABLE artifact_dependencies IS 'Dependency graph used for targeted invalidation and re-evaluation';
COMMENT ON TABLE approvals IS 'Maker-checker approval with frozen evidence snapshot';
COMMENT ON TABLE actions IS 'Idempotent controlled external action';
COMMENT ON TABLE human_decisions IS 'Authorized human consequential decision';
COMMENT ON TABLE audit_events IS 'Append-oriented business, user, service, and AI audit trail';

-- ============================================================
-- 11. OPTIONAL SUPABASE ROW-LEVEL SECURITY BASELINE
-- Review and replace permissive examples with tenant, role, and case assignment rules.
-- ============================================================

ALTER TABLE cases ENABLE ROW LEVEL SECURITY;
ALTER TABLE case_parties ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE case_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE evidence_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE evidence_versions ENABLE ROW LEVEL SECURITY;
ALTER TABLE assertions ENABLE ROW LEVEL SECURITY;
ALTER TABLE case_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE agent_outputs ENABLE ROW LEVEL SECURITY;
ALTER TABLE hypotheses ENABLE ROW LEVEL SECURITY;
ALTER TABLE conclusions ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE approvals ENABLE ROW LEVEL SECURITY;
ALTER TABLE actions ENABLE ROW LEVEL SECURITY;
ALTER TABLE human_decisions ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_events ENABLE ROW LEVEL SECURITY;

-- Development-only authenticated read policies. Replace before production.
CREATE POLICY cases_authenticated_read ON cases
FOR SELECT TO authenticated USING (true);
CREATE POLICY evidence_items_authenticated_read ON evidence_items
FOR SELECT TO authenticated USING (true);
CREATE POLICY evidence_versions_authenticated_read ON evidence_versions
FOR SELECT TO authenticated USING (true);

COMMIT;
