SET search_path TO dispute, public;

WITH customer AS (
  INSERT INTO parties(party_type_code,display_name,external_reference)
  VALUES ('customer','Synthetic Customer','CUST-DEMO-001')
  RETURNING party_id
), merchant AS (
  INSERT INTO parties(party_type_code,display_name,external_reference)
  VALUES ('merchant','Synthetic Electronics','MER-DEMO-001')
  RETURNING party_id
), new_case AS (
  INSERT INTO cases(case_reference,title,narrative,case_state_code,processing_side_code,amount,currency_code,customer_name,merchant_name)
  VALUES ('DSP-DEMO-001','Goods not received','Customer states goods were not delivered.','gathering_evidence','issuer',249.99,'USD','Synthetic Customer','Synthetic Electronics')
  RETURNING case_id
), links AS (
  INSERT INTO case_parties(case_id,party_id,role_code)
  SELECT new_case.case_id,customer.party_id,'customer' FROM new_case,customer
  UNION ALL
  SELECT new_case.case_id,merchant.party_id,'merchant' FROM new_case,merchant
), customer_item AS (
  INSERT INTO evidence_items(case_id,evidence_type_code,subject_type_code,classification_code)
  SELECT case_id,'customer_statement','case','confidential' FROM new_case
  RETURNING evidence_item_id
), merchant_item AS (
  INSERT INTO evidence_items(case_id,evidence_type_code,subject_type_code,classification_code)
  SELECT case_id,'delivery_proof','case','confidential' FROM new_case
  RETURNING evidence_item_id
)
INSERT INTO evidence_versions(evidence_item_id,version_no,evidence_source_code,content_text,valid_at)
SELECT evidence_item_id,1,'customer','Customer states item was not delivered.',now() FROM customer_item
UNION ALL
SELECT evidence_item_id,1,'merchant','Merchant record states delivered with signature.',now() FROM merchant_item;
