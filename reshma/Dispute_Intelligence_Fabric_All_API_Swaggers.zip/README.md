# Dispute Intelligence Fabric OpenAPI Pack

OpenAPI 3.1 specifications for the complete target platform. These are target-design contracts, not claims of live upstream scheme interfaces. Network-specific fields and security profiles require validation with the chosen provider and client standards.

## Files

- `00_dispute_intelligence_fabric_all_apis.yaml`: Dispute Intelligence Fabric API
- `01_case_management.yaml`: Case Management API
- `02_party_transaction.yaml`: Party and Transaction API
- `03_evidence_intelligence.yaml`: Evidence Intelligence API
- `04_ai_agent.yaml`: AI and Agent API
- `05_workflow_approval.yaml`: Workflow, Task and Approval API
- `06_action_integration.yaml`: Action and Integration API
- `07_communication.yaml`: Communication and Evidence Request API
- `08_audit_operations_governance.yaml`: Audit, Operations and AI Governance API
- `09_platform.yaml`: Platform API

## Import
- Swagger Editor / Swagger UI: open any YAML file.
- Postman: Import > File.
- ERwin/API tooling: use the consolidated YAML or the domain YAMLs.

## Key controls
- OAuth2/JWT bearer security baseline.
- Idempotency-Key for side-effecting operations.
- Maker-checker and stale approval conflict responses.
- Evidence versions are immutable.
- Final liability is recorded through an authorized human-decision endpoint.
- Agent recommendations remain advisory.
