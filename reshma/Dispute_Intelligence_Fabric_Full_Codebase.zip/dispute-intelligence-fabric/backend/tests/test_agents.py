from app.agents.graph import graph
def test_graph_preserves_human_boundary():
    r=graph.invoke({"case":{"id":"1"},"evidence":[],"outputs":[]})
    a14=next(x for x in r['outputs'] if x['agent_id']=='A14')
    assert any(x['action']=='final_liability' and not x['permitted'] for x in a14['payload']['items'])
def test_missing_evidence_is_gap_not_conflict():
    r=graph.invoke({"case":{"id":"1"},"evidence":[],"outputs":[]})
    assert next(x for x in r['outputs'] if x['agent_id']=='A09')['payload']['items']==[]
    assert next(x for x in r['outputs'] if x['agent_id']=='A10')['payload']['items']
