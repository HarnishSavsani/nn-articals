import hashlib, uuid
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.db import get_db
from app.models import Case,Evidence,AgentOutput,Approval,Action,AuditEvent
from app.schemas import CaseCreate,CaseOut,EvidenceCreate,EvidenceOut,ApprovalCreate,ApprovalDecision,HumanDecision
from app.agents.graph import graph
router=APIRouter(prefix="/api/v1")
async def audit(db,case_id,actor,event_type,details): db.add(AuditEvent(case_id=case_id,actor=actor,event_type=event_type,details=details))
@router.get('/health')
async def health(): return {"status":"ok"}
@router.get('/cases',response_model=list[CaseOut])
async def cases(db:AsyncSession=Depends(get_db)): return (await db.scalars(select(Case).order_by(Case.created_at.desc()))).all()
@router.post('/cases',response_model=CaseOut)
async def create_case(data:CaseCreate,db:AsyncSession=Depends(get_db)):
    c=Case(reference=f"DSP-{datetime.now().strftime('%Y%m%d')}-{uuid.uuid4().hex[:6].upper()}",**data.model_dump())
    db.add(c); await db.flush(); await audit(db,c.id,"user","CaseCreated",{"state":c.state}); await db.commit(); await db.refresh(c); return c
@router.get('/cases/{case_id}')
async def case_detail(case_id:uuid.UUID,db:AsyncSession=Depends(get_db)):
    c=await db.get(Case,case_id)
    if not c: raise HTTPException(404,"Case not found")
    ev=(await db.scalars(select(Evidence).where(Evidence.case_id==case_id).order_by(Evidence.recorded_at))).all()
    outs=(await db.scalars(select(AgentOutput).where(AgentOutput.case_id==case_id).order_by(AgentOutput.created_at))).all()
    approvals=(await db.scalars(select(Approval).where(Approval.case_id==case_id))).all()
    return {"case":CaseOut.model_validate(c),"evidence":[EvidenceOut.model_validate(x) for x in ev],"outputs":[{"id":str(x.id),"agent_id":x.agent_id,"output_type":x.output_type,"payload":x.payload,"confidence":x.confidence,"stale":x.stale} for x in outs],"approvals":[{"id":str(x.id),"action_type":x.action_type,"status":x.status,"maker":x.maker,"approver":x.approver} for x in approvals]}
@router.post('/cases/{case_id}/evidence',response_model=EvidenceOut)
async def add_evidence(case_id:uuid.UUID,data:EvidenceCreate,db:AsyncSession=Depends(get_db)):
    if not await db.get(Case,case_id): raise HTTPException(404,"Case not found")
    version=1
    if data.supersedes_id:
        prior=await db.get(Evidence,data.supersedes_id)
        if not prior or prior.case_id!=case_id: raise HTTPException(400,"Invalid superseded evidence")
        version=prior.version+1
        await db.execute(update(AgentOutput).where(AgentOutput.case_id==case_id).values(stale=True))
        for a in (await db.scalars(select(Approval).where(Approval.case_id==case_id,Approval.status=='pending'))).all(): a.status='paused'
    raw=data.model_dump(exclude={'valid_at'}); raw['valid_at']=data.valid_at or datetime.now(timezone.utc)
    e=Evidence(case_id=case_id,version=version,sha256=hashlib.sha256(data.content.encode()).hexdigest(),**raw)
    db.add(e); await db.flush(); await audit(db,case_id,"user","EvidenceCorrected" if data.supersedes_id else "EvidenceReceived",{"evidence_id":str(e.id),"version":version}); await db.commit(); await db.refresh(e); return e
@router.post('/cases/{case_id}/analyze')
async def analyze(case_id:uuid.UUID,db:AsyncSession=Depends(get_db)):
    c=await db.get(Case,case_id)
    if not c: raise HTTPException(404,"Case not found")
    ev=(await db.scalars(select(Evidence).where(Evidence.case_id==case_id))).all()
    state={"case":{"id":str(c.id),"narrative":c.narrative},"evidence":[{"id":str(x.id),"kind":x.kind,"source":x.source,"content":x.content} for x in ev],"outputs":[]}
    result=graph.invoke(state)
    for x in result['outputs']: db.add(AgentOutput(case_id=case_id,**x))
    c.state='interpretation_ready'; await audit(db,case_id,"agent-coordinator","AnalysisCompleted",{"agents":[x['agent_id'] for x in result['outputs']]}); await db.commit()
    return {"status":"completed","outputs":result['outputs']}
@router.post('/cases/{case_id}/approvals')
async def create_approval(case_id:uuid.UUID,data:ApprovalCreate,db:AsyncSession=Depends(get_db)):
    ids=[str(x) for x in (await db.scalars(select(Evidence.id).where(Evidence.case_id==case_id))).all()]
    a=Approval(case_id=case_id,evidence_snapshot=ids,**data.model_dump());db.add(a);await db.flush();await audit(db,case_id,data.maker,"ApprovalRequested",{"approval_id":str(a.id)});await db.commit();return {"id":a.id,"status":a.status}
@router.post('/approvals/{approval_id}/decision')
async def decide(approval_id:uuid.UUID,data:ApprovalDecision,db:AsyncSession=Depends(get_db)):
    a=await db.get(Approval,approval_id)
    if not a: raise HTTPException(404,"Approval not found")
    if a.maker==data.approver: raise HTTPException(409,"Maker-checker segregation violation")
    if a.status=='paused': raise HTTPException(409,"Approval paused by material evidence change")
    a.status=data.status;a.approver=data.approver;a.rationale=data.rationale;await audit(db,a.case_id,data.approver,"ApprovalDecided",{"status":data.status});await db.commit();return {"status":a.status}
@router.post('/cases/{case_id}/human-decision')
async def human_decision(case_id:uuid.UUID,data:HumanDecision,db:AsyncSession=Depends(get_db)):
    c=await db.get(Case,case_id)
    if not c: raise HTTPException(404,"Case not found")
    c.final_liability=data.liability;c.state='closed';await audit(db,case_id,data.actor,"HumanDecisionRecorded",data.model_dump());await db.commit();return {"state":c.state,"liability":c.final_liability}
@router.post('/cases/{case_id}/actions/{action_type}')
async def prepare_action(case_id:uuid.UUID,action_type:str,idempotency_key:str,db:AsyncSession=Depends(get_db)):
    existing=await db.scalar(select(Action).where(Action.idempotency_key==idempotency_key))
    if existing:return {"id":existing.id,"status":existing.status,"duplicate":True}
    approved=await db.scalar(select(Approval).where(Approval.case_id==case_id,Approval.action_type==action_type,Approval.status=='approved'))
    if not approved: raise HTTPException(409,"Approved current snapshot required")
    a=Action(case_id=case_id,action_type=action_type,idempotency_key=idempotency_key,status='prepared');db.add(a);await db.flush();await audit(db,case_id,"action-gateway","ActionPrepared",{"action_id":str(a.id)});await db.commit();return {"id":a.id,"status":a.status,"duplicate":False}
@router.get('/cases/{case_id}/audit')
async def get_audit(case_id:uuid.UUID,db:AsyncSession=Depends(get_db)):
    xs=(await db.scalars(select(AuditEvent).where(AuditEvent.case_id==case_id).order_by(AuditEvent.created_at))).all()
    return [{"id":str(x.id),"actor":x.actor,"event_type":x.event_type,"details":x.details,"created_at":x.created_at} for x in xs]
@router.post('/admin/seed')
async def seed(db:AsyncSession=Depends(get_db)):
    if await db.scalar(select(Case).limit(1)): return {"status":"already_seeded"}
    c=Case(reference='DSP-DEMO-001',title='Goods not received',narrative='Customer states goods were not delivered.',amount=249.99,currency='USD',merchant_name='Synthetic Electronics')
    db.add(c);await db.flush()
    db.add_all([Evidence(case_id=c.id,kind='customer_statement',source='customer',content='Customer states item was not delivered.'),Evidence(case_id=c.id,kind='delivery_proof',source='merchant',content='Merchant record says delivered with signature.')])
    await audit(db,c.id,'seed','CaseCreated',{'synthetic':True});await db.commit();return {"status":"seeded","case_id":str(c.id)}
