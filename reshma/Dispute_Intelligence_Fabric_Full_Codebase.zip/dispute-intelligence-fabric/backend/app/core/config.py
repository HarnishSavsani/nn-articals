from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict
class Settings(BaseSettings):
    environment: str = "local"
    database_url: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/disputes"
    cors_origins: str = "http://localhost:5173"
    supabase_url: str = ""
    supabase_service_role_key: str = ""
    llm_provider: str = "mock"
    llm_model: str = "mock-dispute-v1"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    @property
    def cors(self): return [x.strip() for x in self.cors_origins.split(",")]
@lru_cache
def settings(): return Settings()
