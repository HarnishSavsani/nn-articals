from datetime import datetime
from uuid import UUID
from pydantic import BaseModel, Field, ConfigDict
class CaseCreate(BaseModel):
    title:str; narrative:str; amount:float=0; currency:str="USD"; side:str="issuer"; customer_name:str="Synthetic Customer"; merchant_name:str="Synthetic Merchant"
class EvidenceCreate(BaseModel):
    kind:str; source:str; content:str; valid_at:datetime|None=None; supersedes_id:UUID|None=None
class CaseOut(BaseModel):
    model_config=ConfigDict(from_attributes=True)
    id:UUID; reference:str; title:str; narrative:str; state:str; side:str; amount:float; currency:str; customer_name:str; merchant_name:str; final_liability:str|None; created_at:datetime
class EvidenceOut(BaseModel):
    model_config=ConfigDict(from_attributes=True)
    id:UUID; case_id:UUID; kind:str; source:str; content:str; version:int; supersedes_id:UUID|None; recorded_at:datetime
class ApprovalCreate(BaseModel): action_type:str; maker:str="investigator@example.test"
class ApprovalDecision(BaseModel): status:str=Field(pattern="^(approved|rejected)$"); approver:str; rationale:str
class HumanDecision(BaseModel): liability:str=Field(pattern="^(customer|merchant|shared|no_liability)$"); actor:str; rationale:str
