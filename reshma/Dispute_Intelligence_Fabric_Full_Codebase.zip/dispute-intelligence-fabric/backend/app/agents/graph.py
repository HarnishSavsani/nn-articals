from typing import TypedDict
from langgraph.graph import StateGraph, START, END
class DisputeState(TypedDict, total=False):
    case:dict; evidence:list[dict]; outputs:list[dict]
def node(agent_id, output_type):
    def run(state:DisputeState):
        ev=state.get("evidence",[]); ids=[str(x.get("id")) for x in ev]
        text=" ".join(x.get("content","").lower() for x in ev)
        payload={"summary":f"{agent_id} evaluated {len(ev)} evidence item(s)","uncertainty":"review_required"}
        if agent_id=="A09": payload["items"]=[{"type":"direct","statement":"Customer and merchant narratives differ","material":True}] if "not delivered" in text and "delivered" in text else []
        if agent_id=="A10": payload["items"]=[] if ev else [{"missing":"supporting evidence","reason":"No evidence registered"}]
        if agent_id=="A11": payload["items"]=[{"name":"customer_claim_supported","status":"possible"},{"name":"merchant_response_supported","status":"possible"}]
        if agent_id=="A14": payload["items"]=[{"action":"specialist_review","permitted":True},{"action":"final_liability","permitted":False}]
        out={"agent_id":agent_id,"output_type":output_type,"payload":payload,"evidence_ids":ids,"confidence":0.72}
        return {"outputs":state.get("outputs",[])+[out]}
    return run
def build_graph():
    g=StateGraph(DisputeState)
    sequence=[("A02","classification"),("A03","assertions"),("A04","provenance"),("A05","entity_links"),("A06","duplicates"),("A07","quality"),("A08","timeline"),("A09","contradictions"),("A10","gaps"),("A11","hypotheses"),("A12","impact"),("A13","evidence_recommendations"),("A14","action_recommendations"),("A15","review_pack")]
    for a,t in sequence:g.add_node(a,node(a,t))
    g.add_edge(START,sequence[0][0])
    for x,y in zip(sequence,sequence[1:]):g.add_edge(x[0],y[0])
    g.add_edge(sequence[-1][0],END)
    return g.compile()
graph=build_graph()
