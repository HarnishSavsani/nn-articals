from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.config import settings
from app.core.db import engine
from app.models import Base
from app.api import router
@asynccontextmanager
async def lifespan(app):
    async with engine.begin() as conn: await conn.run_sync(Base.metadata.create_all)
    yield
app=FastAPI(title="Dispute Intelligence Fabric API",version="0.1.0",lifespan=lifespan)
app.add_middleware(CORSMiddleware,allow_origins=settings().cors,allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
app.include_router(router)
