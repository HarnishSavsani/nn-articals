import uuid
from datetime import datetime, timezone
from sqlalchemy import String, Text, DateTime, ForeignKey, Numeric, Boolean, JSON, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID

def now(): return datetime.now(timezone.utc)
class Base(DeclarativeBase): pass
class Case(Base):
    __tablename__="cases"
    id: Mapped[uuid.UUID]=mapped_column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4)
    reference: Mapped[str]=mapped_column(String(40),unique=True,index=True)
    title: Mapped[str]=mapped_column(String(200))
    narrative: Mapped[str]=mapped_column(Text)
    state: Mapped[str]=mapped_column(String(40),default="raised",index=True)
    side: Mapped[str]=mapped_column(String(20),default="issuer")
    amount: Mapped[float]=mapped_column(Numeric(18,2),default=0)
    currency: Mapped[str]=mapped_column(String(3),default="USD")
    customer_name: Mapped[str]=mapped_column(String(120),default="Synthetic Customer")
    merchant_name: Mapped[str]=mapped_column(String(120),default="Synthetic Merchant")
    final_liability: Mapped[str|None]=mapped_column(String(32),nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
    updated_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now,onupdate=now)
    evidence: Mapped[list["Evidence"]]=relationship(cascade="all, delete-orphan",lazy="selectin")
class Evidence(Base):
    __tablename__="evidence"
    id: Mapped[uuid.UUID]=mapped_column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4)
    case_id: Mapped[uuid.UUID]=mapped_column(ForeignKey("cases.id",ondelete="CASCADE"),index=True)
    kind: Mapped[str]=mapped_column(String(50))
    source: Mapped[str]=mapped_column(String(50))
    content: Mapped[str]=mapped_column(Text)
    version: Mapped[int]=mapped_column(default=1)
    supersedes_id: Mapped[uuid.UUID|None]=mapped_column(UUID(as_uuid=True),nullable=True)
    object_path: Mapped[str|None]=mapped_column(Text,nullable=True)
    sha256: Mapped[str|None]=mapped_column(String(64),nullable=True)
    valid_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
    recorded_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class AgentOutput(Base):
    __tablename__="agent_outputs"
    id: Mapped[uuid.UUID]=mapped_column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4)
    case_id: Mapped[uuid.UUID]=mapped_column(ForeignKey("cases.id",ondelete="CASCADE"),index=True)
    agent_id: Mapped[str]=mapped_column(String(10),index=True)
    output_type: Mapped[str]=mapped_column(String(50))
    payload: Mapped[dict]=mapped_column(JSON)
    evidence_ids: Mapped[list]=mapped_column(JSON,default=list)
    confidence: Mapped[float]=mapped_column(default=0.0)
    stale: Mapped[bool]=mapped_column(Boolean,default=False)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Approval(Base):
    __tablename__="approvals"
    id: Mapped[uuid.UUID]=mapped_column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4)
    case_id: Mapped[uuid.UUID]=mapped_column(ForeignKey("cases.id",ondelete="CASCADE"),index=True)
    action_type: Mapped[str]=mapped_column(String(80))
    maker: Mapped[str]=mapped_column(String(120))
    approver: Mapped[str|None]=mapped_column(String(120),nullable=True)
    status: Mapped[str]=mapped_column(String(20),default="pending")
    evidence_snapshot: Mapped[list]=mapped_column(JSON,default=list)
    rationale: Mapped[str|None]=mapped_column(Text,nullable=True)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class Action(Base):
    __tablename__="actions"; __table_args__=(UniqueConstraint("idempotency_key"),)
    id: Mapped[uuid.UUID]=mapped_column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4)
    case_id: Mapped[uuid.UUID]=mapped_column(ForeignKey("cases.id",ondelete="CASCADE"),index=True)
    action_type: Mapped[str]=mapped_column(String(80))
    idempotency_key: Mapped[str]=mapped_column(String(160))
    status: Mapped[str]=mapped_column(String(20),default="prepared")
    external_reference: Mapped[str|None]=mapped_column(String(120),nullable=True)
    result: Mapped[dict]=mapped_column(JSON,default=dict)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
class AuditEvent(Base):
    __tablename__="audit_events"
    id: Mapped[uuid.UUID]=mapped_column(UUID(as_uuid=True),primary_key=True,default=uuid.uuid4)
    case_id: Mapped[uuid.UUID|None]=mapped_column(UUID(as_uuid=True),nullable=True,index=True)
    actor: Mapped[str]=mapped_column(String(120))
    event_type: Mapped[str]=mapped_column(String(80),index=True)
    details: Mapped[dict]=mapped_column(JSON,default=dict)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)
