# Dispute Intelligence Fabric

GitHub-ready full-stack MVP for bilateral card dispute handling across customer, issuer, merchant, acquirer and network journeys.

## Stack
- React 18 + TypeScript + Vite
- Python 3.12 + FastAPI
- PostgreSQL / Supabase
- LangGraph orchestration with deterministic safe fallback
- Supabase Auth, Storage and Row-Level Security-ready schema
- Docker Compose and GitHub Actions

## Included capabilities
- Case intake and dashboard
- Immutable evidence versions
- Timeline, assertions, contradictions, gaps and hypotheses
- 17 bounded agent definitions
- Targeted material-change re-evaluation
- Human review and maker-checker approval
- Idempotent action ledger
- Merchant representment episode
- Audit events and point-in-time data model
- Synthetic seed data

## Start locally
```bash
cp .env.example .env
docker compose up --build
```
Open `http://localhost:5173`. API docs: `http://localhost:8000/docs`.

## Run without Docker
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -e '.[dev]'
alembic upgrade head
uvicorn app.main:app --reload

cd ../frontend
npm install
npm run dev
```

## Supabase cloud
1. Create a Supabase project.
2. Run `supabase/migrations/0001_init.sql` in SQL Editor or use the Supabase CLI.
3. Create a private Storage bucket named `evidence`.
4. Set the backend `DATABASE_URL`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, and frontend `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`.
5. Keep the service role key on the backend only.

## LLM configuration
Default `LLM_PROVIDER=mock` runs fully offline with deterministic agent outputs. To connect a provider, implement `backend/app/agents/llm.py` and configure only an organization-approved model endpoint. Consequential decisions remain human-owned.

## GitHub export
Unzip, create an empty repository, then:
```bash
git init
git add .
git commit -m "Initial Dispute Intelligence Fabric MVP"
git branch -M main
git remote add origin <your-repository-url>
git push -u origin main
```

## Important
This is an executable MVP baseline, not a certified production release. Scheme rules, PCI scope, legal requirements, SLAs, integrations, model approvals and security controls must be validated before production use.
