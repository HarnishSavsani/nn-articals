from pathlib import Path
import ast,json
r=Path(__file__).parents[1]
for p in (r/'backend').rglob('*.py'): ast.parse(p.read_text(),filename=str(p))
json.loads((r/'frontend/package.json').read_text())
required=['README.md','docker-compose.yml','backend/app/main.py','backend/app/agents/graph.py','frontend/src/App.tsx','supabase/migrations/0001_init.sql','.github/workflows/ci.yml']
for x in required: assert (r/x).exists(),x
print('OK',sum(1 for p in r.rglob('*') if p.is_file()),'files')
