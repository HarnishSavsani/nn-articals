# Architecture

React calls the FastAPI BFF/API. FastAPI owns authorization, case state, evidence metadata, approval and action APIs. PostgreSQL/Supabase stores operational state and audit data. Supabase Storage may hold original evidence. LangGraph coordinates bounded analytical agents while policy, approvals and external actions stay deterministic.

## Agent flow
`intake -> evidence -> reconstruct -> compare -> gaps -> hypotheses -> materiality -> recommendations -> reviewer pack`

## Safety boundaries
- Agents cannot record final liability.
- Agents cannot approve their own recommendation.
- Agents cannot execute ledger or scheme actions.
- Every material output carries evidence IDs and confidence/uncertainty.
- Material evidence changes stale dependent recommendations and pending approvals.
