# Dispute Intelligence Fabric Sample Data

These PostgreSQL/Supabase sample-data scripts are designed for the enterprise DDL in `dispute_intelligence_fabric_full_ddl.sql`.

## Execution order
1. Run the full DDL.
2. Run `00_sample_master_data.sql`.
3. Run one or more scenario scripts, or run `99_all_samples.sql`.

## Scenarios
- `01_late_merchant_evidence.sql`: customer claims non-delivery; merchant evidence arrives later and contradicts the claim.
- `02_unauthorized_transaction.sql`: customer disputes a card-not-present transaction with authentication evidence.
- `03_duplicate_billing.sql`: two similar transactions and a duplicate-billing claim.
- `04_refund_not_processed.sql`: merchant states refund was processed; ledger does not yet show the refund.
- `05_merchant_representment.sql`: acquirer/merchant-side representment with approval and network submission.

All names, references, account tokens, evidence, amounts, and events are synthetic. No live or confidential data is included.
