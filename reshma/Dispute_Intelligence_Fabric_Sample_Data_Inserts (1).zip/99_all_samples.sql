-- Run this file with psql from this directory after the DDL.
\ir 00_sample_master_data.sql
\ir 01_late_merchant_evidence.sql
\ir 02_unauthorized_transaction.sql
\ir 03_duplicate_billing.sql
\ir 04_refund_not_processed.sql
\ir 05_merchant_representment.sql
