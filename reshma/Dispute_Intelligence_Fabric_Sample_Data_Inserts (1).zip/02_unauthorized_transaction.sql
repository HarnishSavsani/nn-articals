SET search_path TO dispute, public;
INSERT INTO parties(party_id,party_type_code,display_name,external_reference,status_code) VALUES
('30000000-0000-0000-0000-000000000001','customer','Synthetic Customer B','CUST-B','active'),
('30000000-0000-0000-0000-000000000002','merchant','Synthetic Online Marketplace','MER-B','active') ON CONFLICT DO NOTHING;
INSERT INTO cases(case_id,case_reference,title,narrative,case_state_code,processing_side_code,amount,currency_code,customer_name,merchant_name,jurisdiction_code) VALUES
('31000000-0000-0000-0000-000000000001','DSP-UNAUTH-001','Unauthorized transaction','Customer states the purchase was not authorized.','interpretation_ready','issuer',89.50,'USD','Synthetic Customer B','Synthetic Online Marketplace','DEMO') ON CONFLICT DO NOTHING;
INSERT INTO case_parties(case_party_id,case_id,party_id,role_code) VALUES
('31100000-0000-0000-0000-000000000001','31000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001','customer'),
('31100000-0000-0000-0000-000000000002','31000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000002','merchant') ON CONFLICT DO NOTHING;
INSERT INTO transactions(transaction_id,external_transaction_ref,merchant_party_id,authorization_code,tokenized_account_ref,transaction_amount,currency_code,transaction_at,posted_at,transaction_status_code) VALUES
('31200000-0000-0000-0000-000000000001','TXN-UNAUTH-001','30000000-0000-0000-0000-000000000002','AUTH-B001','tok_demo_0002',89.50,'USD',now()-interval '12 days',now()-interval '11 days','posted') ON CONFLICT DO NOTHING;
INSERT INTO case_transactions(case_id,transaction_id,relationship_type_code,disputed_amount) VALUES
('31000000-0000-0000-0000-000000000001','31200000-0000-0000-0000-000000000001','RELATES_TO',89.50) ON CONFLICT DO NOTHING;
INSERT INTO evidence_items(evidence_item_id,case_id,evidence_type_code,subject_type_code,subject_id,classification_code,status_code) VALUES
('31300000-0000-0000-0000-000000000001','31000000-0000-0000-0000-000000000001','customer_statement','case','31000000-0000-0000-0000-000000000001','confidential','open'),
('31300000-0000-0000-0000-000000000002','31000000-0000-0000-0000-000000000001','authentication_event','transaction','31200000-0000-0000-0000-000000000001','restricted','open') ON CONFLICT DO NOTHING;
INSERT INTO evidence_versions(evidence_version_id,evidence_item_id,version_no,evidence_source_code,content_text,sha256_hash,valid_at) VALUES
('31400000-0000-0000-0000-000000000001','31300000-0000-0000-0000-000000000001',1,'customer','I did not authorize this purchase.','cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc',now()-interval '10 days'),
('31400000-0000-0000-0000-000000000002','31300000-0000-0000-0000-000000000002',1,'authentication_system','3DS challenge completed for the transaction.','dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd',now()-interval '12 days') ON CONFLICT DO NOTHING;
INSERT INTO case_events(case_event_id,case_id,event_type_code,event_at,evidence_version_id,event_payload_json,certainty_code) VALUES
('31500000-0000-0000-0000-000000000001','31000000-0000-0000-0000-000000000001','3ds_challenge_completed',now()-interval '12 days','31400000-0000-0000-0000-000000000002','{"result":"success"}','observed') ON CONFLICT DO NOTHING;
INSERT INTO tasks(task_id,case_id,task_type_code,assigned_role_code,assigned_user_id,status_code,due_at,workflow_reference) VALUES
('31600000-0000-0000-0000-000000000001','31000000-0000-0000-0000-000000000001','specialist_review','fraud_specialist','10000000-0000-0000-0000-000000000011','open',now()+interval '1 day','WF-UNAUTH-001') ON CONFLICT DO NOTHING;
INSERT INTO audit_events(audit_event_id,case_id,actor_type_code,actor_id,event_type_code,details_json) VALUES
('31700000-0000-0000-0000-000000000001','31000000-0000-0000-0000-000000000001','system','seed','CaseCreated','{"synthetic":true}') ON CONFLICT DO NOTHING;
