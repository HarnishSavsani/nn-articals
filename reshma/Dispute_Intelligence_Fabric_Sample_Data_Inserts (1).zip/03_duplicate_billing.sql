SET search_path TO dispute, public;
INSERT INTO parties(party_id,party_type_code,display_name,external_reference,status_code) VALUES
('40000000-0000-0000-0000-000000000001','customer','Synthetic Customer C','CUST-C','active'),
('40000000-0000-0000-0000-000000000002','merchant','Synthetic Subscription Service','MER-C','active') ON CONFLICT DO NOTHING;
INSERT INTO cases(case_id,case_reference,title,narrative,case_state_code,processing_side_code,amount,currency_code,customer_name,merchant_name,jurisdiction_code) VALUES
('41000000-0000-0000-0000-000000000001','DSP-DUP-001','Duplicate billing','Customer reports two charges for one subscription.','gathering_evidence','issuer',39.98,'USD','Synthetic Customer C','Synthetic Subscription Service','DEMO') ON CONFLICT DO NOTHING;
INSERT INTO transactions(transaction_id,external_transaction_ref,merchant_party_id,authorization_code,tokenized_account_ref,transaction_amount,currency_code,transaction_at,posted_at,transaction_status_code) VALUES
('41200000-0000-0000-0000-000000000001','TXN-DUP-001-A','40000000-0000-0000-0000-000000000002','AUTH-C001','tok_demo_0003',19.99,'USD',now()-interval '8 days',now()-interval '7 days','posted'),
('41200000-0000-0000-0000-000000000002','TXN-DUP-001-B','40000000-0000-0000-0000-000000000002','AUTH-C002','tok_demo_0003',19.99,'USD',now()-interval '8 days'+interval '2 minutes',now()-interval '7 days','posted') ON CONFLICT DO NOTHING;
INSERT INTO case_transactions(case_id,transaction_id,relationship_type_code,disputed_amount) VALUES
('41000000-0000-0000-0000-000000000001','41200000-0000-0000-0000-000000000001','RELATES_TO',19.99),
('41000000-0000-0000-0000-000000000001','41200000-0000-0000-0000-000000000002','DUPLICATES',19.99) ON CONFLICT DO NOTHING;
INSERT INTO evidence_items(evidence_item_id,case_id,evidence_type_code,subject_type_code,subject_id,classification_code,status_code) VALUES
('41300000-0000-0000-0000-000000000001','41000000-0000-0000-0000-000000000001','transaction_event','case','41000000-0000-0000-0000-000000000001','restricted','open') ON CONFLICT DO NOTHING;
INSERT INTO evidence_versions(evidence_version_id,evidence_item_id,version_no,evidence_source_code,content_text,sha256_hash,valid_at) VALUES
('41400000-0000-0000-0000-000000000001','41300000-0000-0000-0000-000000000001',1,'core_card_system','Two equal-value transactions posted within two minutes.','eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee',now()-interval '8 days') ON CONFLICT DO NOTHING;
INSERT INTO audit_events(audit_event_id,case_id,actor_type_code,actor_id,event_type_code,details_json) VALUES
('41700000-0000-0000-0000-000000000001','41000000-0000-0000-0000-000000000001','system','seed','CaseCreated','{"synthetic":true,"scenario":"duplicate_billing"}') ON CONFLICT DO NOTHING;
