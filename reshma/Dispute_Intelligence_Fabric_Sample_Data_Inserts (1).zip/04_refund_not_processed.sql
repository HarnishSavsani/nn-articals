SET search_path TO dispute, public;
INSERT INTO parties(party_id,party_type_code,display_name,external_reference,status_code) VALUES
('50000000-0000-0000-0000-000000000001','customer','Synthetic Customer D','CUST-D','active'),
('50000000-0000-0000-0000-000000000002','merchant','Synthetic Travel Merchant','MER-D','active') ON CONFLICT DO NOTHING;
INSERT INTO cases(case_id,case_reference,title,narrative,case_state_code,processing_side_code,amount,currency_code,customer_name,merchant_name,jurisdiction_code) VALUES
('51000000-0000-0000-0000-000000000001','DSP-REFUND-001','Refund not processed','Customer states an agreed refund is not visible.','awaiting_evidence','issuer',450.00,'USD','Synthetic Customer D','Synthetic Travel Merchant','DEMO') ON CONFLICT DO NOTHING;
INSERT INTO evidence_items(evidence_item_id,case_id,evidence_type_code,subject_type_code,subject_id,classification_code,status_code) VALUES
('51300000-0000-0000-0000-000000000001','51000000-0000-0000-0000-000000000001','refund_record','case','51000000-0000-0000-0000-000000000001','confidential','open'),
('51300000-0000-0000-0000-000000000002','51000000-0000-0000-0000-000000000001','reconciliation_record','case','51000000-0000-0000-0000-000000000001','restricted','open') ON CONFLICT DO NOTHING;
INSERT INTO evidence_versions(evidence_version_id,evidence_item_id,version_no,evidence_source_code,content_text,sha256_hash,valid_at) VALUES
('51400000-0000-0000-0000-000000000001','51300000-0000-0000-0000-000000000001',1,'merchant','Merchant refund reference RF-DEMO-001 created.','ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',now()-interval '5 days'),
('51400000-0000-0000-0000-000000000002','51300000-0000-0000-0000-000000000002',1,'reconciliation_system','No matching refund posting found as of reconciliation run.','1111111111111111111111111111111111111111111111111111111111111111',now()-interval '1 day') ON CONFLICT DO NOTHING;
INSERT INTO tasks(task_id,case_id,task_type_code,assigned_role_code,status_code,due_at,workflow_reference) VALUES
('51600000-0000-0000-0000-000000000001','51000000-0000-0000-0000-000000000001','request_acquirer_refund_status','investigator','open',now()+interval '1 day','WF-REFUND-001') ON CONFLICT DO NOTHING;
INSERT INTO audit_events(audit_event_id,case_id,actor_type_code,actor_id,event_type_code,details_json) VALUES
('51700000-0000-0000-0000-000000000001','51000000-0000-0000-0000-000000000001','system','seed','CaseCreated','{"synthetic":true,"scenario":"refund_not_processed"}') ON CONFLICT DO NOTHING;
