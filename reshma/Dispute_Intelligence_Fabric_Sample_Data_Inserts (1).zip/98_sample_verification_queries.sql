SET search_path TO dispute, public;

SELECT case_reference, title, case_state_code, processing_side_code, amount, currency_code
FROM cases ORDER BY case_reference;

SELECT c.case_reference, ei.evidence_type_code, ev.version_no, ev.evidence_source_code, ev.recorded_at
FROM cases c
JOIN evidence_items ei ON ei.case_id=c.case_id
JOIN evidence_versions ev ON ev.evidence_item_id=ei.evidence_item_id
ORDER BY c.case_reference, ei.evidence_item_id, ev.version_no;

SELECT c.case_reference, ar.relationship_type_code, ar.severity_code
FROM assertion_relationships ar
JOIN assertions a ON a.assertion_id=ar.source_assertion_id
JOIN cases c ON c.case_id=a.case_id;

SELECT c.case_reference, ap.action_type_code, ap.status_code, a.status_code AS action_status
FROM approvals ap
JOIN cases c ON c.case_id=ap.case_id
LEFT JOIN actions a ON a.approval_id=ap.approval_id;

SELECT c.case_reference, ae.event_type_code, ae.actor_type_code, ae.actor_id, ae.created_at
FROM audit_events ae
LEFT JOIN cases c ON c.case_id=ae.case_id
ORDER BY ae.created_at;
