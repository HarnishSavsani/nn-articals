SET search_path TO dispute, public;
INSERT INTO parties(party_id,party_type_code,display_name,external_reference,status_code) VALUES
('60000000-0000-0000-0000-000000000001','customer','Synthetic Customer E','CUST-E','active'),
('60000000-0000-0000-0000-000000000002','merchant','Synthetic Furniture Merchant','MER-E','active') ON CONFLICT DO NOTHING;
INSERT INTO cases(case_id,case_reference,title,narrative,case_state_code,processing_side_code,amount,currency_code,customer_name,merchant_name,jurisdiction_code) VALUES
('61000000-0000-0000-0000-000000000001','DSP-REP-001','Merchant representment','Merchant contests a non-delivery chargeback with delivery and correspondence evidence.','approval_pending','merchant',799.00,'USD','Synthetic Customer E','Synthetic Furniture Merchant','DEMO') ON CONFLICT DO NOTHING;
INSERT INTO case_parties(case_party_id,case_id,party_id,role_code) VALUES
('61100000-0000-0000-0000-000000000001','61000000-0000-0000-0000-000000000001','60000000-0000-0000-0000-000000000001','customer'),
('61100000-0000-0000-0000-000000000002','61000000-0000-0000-0000-000000000001','60000000-0000-0000-0000-000000000002','merchant'),
('61100000-0000-0000-0000-000000000003','61000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000002','acquirer') ON CONFLICT DO NOTHING;
INSERT INTO evidence_items(evidence_item_id,case_id,evidence_type_code,subject_type_code,subject_id,classification_code,status_code) VALUES
('61300000-0000-0000-0000-000000000001','61000000-0000-0000-0000-000000000001','delivery_proof','case','61000000-0000-0000-0000-000000000001','confidential','open'),
('61300000-0000-0000-0000-000000000002','61000000-0000-0000-0000-000000000001','correspondence','case','61000000-0000-0000-0000-000000000001','confidential','open') ON CONFLICT DO NOTHING;
INSERT INTO evidence_versions(evidence_version_id,evidence_item_id,version_no,evidence_source_code,content_text,sha256_hash,valid_at) VALUES
('61400000-0000-0000-0000-000000000001','61300000-0000-0000-0000-000000000001',1,'merchant','Signed delivery confirmation for order ORD-DEMO-E.','2222222222222222222222222222222222222222222222222222222222222222',now()-interval '25 days'),
('61400000-0000-0000-0000-000000000002','61300000-0000-0000-0000-000000000002',1,'merchant','Customer correspondence acknowledges receipt and requests later return.','3333333333333333333333333333333333333333333333333333333333333333',now()-interval '24 days') ON CONFLICT DO NOTHING;
INSERT INTO approvals(approval_id,case_id,action_type_code,maker_user_id,approver_user_id,status_code,rationale,decided_at) VALUES
('61c00000-0000-0000-0000-000000000001','61000000-0000-0000-0000-000000000001','representment_submission','10000000-0000-0000-0000-000000000013','10000000-0000-0000-0000-000000000012','approved','Representment evidence package reviewed and approved.',now()-interval '1 hour') ON CONFLICT DO NOTHING;
INSERT INTO approval_evidence_snapshot(approval_id,evidence_version_id) VALUES
('61c00000-0000-0000-0000-000000000001','61400000-0000-0000-0000-000000000001'),
('61c00000-0000-0000-0000-000000000001','61400000-0000-0000-0000-000000000002') ON CONFLICT DO NOTHING;
INSERT INTO actions(action_id,case_id,approval_id,action_type_code,idempotency_key,status_code,external_reference,result_payload_json) VALUES
('61d00000-0000-0000-0000-000000000001','61000000-0000-0000-0000-000000000001','61c00000-0000-0000-0000-000000000001','representment_submission','DSP-REP-001:representment:1','submitted','NET-REP-DEMO-001','{"acknowledged":true}') ON CONFLICT DO NOTHING;
INSERT INTO action_attempts(action_attempt_id,action_id,attempt_number,request_payload_hash,started_at,completed_at,outcome_code,external_reference,response_payload_json) VALUES
('61e00000-0000-0000-0000-000000000001','61d00000-0000-0000-0000-000000000001',1,'4444444444444444444444444444444444444444444444444444444444444444',now()-interval '50 minutes',now()-interval '49 minutes','accepted','NET-REP-DEMO-001','{"network_status":"received"}') ON CONFLICT DO NOTHING;
INSERT INTO integration_events(integration_event_id,case_id,event_type_code,schema_version,source_system_code,correlation_id,idempotency_key,payload_json,occurred_at,processing_status_code) VALUES
('61f00000-0000-0000-0000-000000000001','61000000-0000-0000-0000-000000000001','RepresentmentSubmitted','1.0','action_gateway','61f00000-0000-0000-0000-000000000010','DSP-REP-001:representment:1','{"external_reference":"NET-REP-DEMO-001"}',now()-interval '50 minutes','succeeded') ON CONFLICT DO NOTHING;
INSERT INTO audit_events(audit_event_id,case_id,actor_type_code,actor_id,event_type_code,object_type_code,object_id,details_json) VALUES
('61a00000-0000-0000-0000-000000000001','61000000-0000-0000-0000-000000000001','human','USR-APR-001','ApprovalDecided','approval','61c00000-0000-0000-0000-000000000001','{"status":"approved"}'),
('61a00000-0000-0000-0000-000000000002','61000000-0000-0000-0000-000000000001','service','action_gateway','ActionSubmitted','action','61d00000-0000-0000-0000-000000000001','{"external_reference":"NET-REP-DEMO-001"}') ON CONFLICT DO NOTHING;
