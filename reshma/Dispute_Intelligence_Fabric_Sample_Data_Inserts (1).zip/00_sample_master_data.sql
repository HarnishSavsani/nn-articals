SET search_path TO dispute, public;

-- Synthetic institutions, employees, and external parties.
INSERT INTO parties(party_id,party_type_code,display_name,external_reference,status_code) VALUES
('10000000-0000-0000-0000-000000000001','issuer','Synthetic Issuer Bank','ISS-DEMO-001','active'),
('10000000-0000-0000-0000-000000000002','acquirer','Synthetic Acquirer','ACQ-DEMO-001','active'),
('10000000-0000-0000-0000-000000000003','network','Synthetic Card Network','NET-DEMO-001','active'),
('10000000-0000-0000-0000-000000000010','employee','Alex Investigator','USR-INV-001','active'),
('10000000-0000-0000-0000-000000000011','employee','Sam Specialist','USR-SPL-001','active'),
('10000000-0000-0000-0000-000000000012','employee','Taylor Approver','USR-APR-001','active'),
('10000000-0000-0000-0000-000000000013','employee','Jordan Merchant Specialist','USR-MER-001','active'),
('10000000-0000-0000-0000-000000000014','employee','Casey Auditor','USR-AUD-001','active'),
('10000000-0000-0000-0000-000000000015','courier','Synthetic Delivery Partner','CUR-DEMO-001','active')
ON CONFLICT DO NOTHING;

INSERT INTO policy_versions(policy_version_id,policy_code,version_no,jurisdiction_code,effective_from,policy_payload_json) VALUES
('11000000-0000-0000-0000-000000000001','DISPUTE_ELIGIBILITY','1.0','DEMO',now()-interval '1 year',
 '{"max_age_days":120,"human_final_liability_required":true}'::jsonb),
('11000000-0000-0000-0000-000000000002','MAKER_CHECKER','1.0','DEMO',now()-interval '1 year',
 '{"segregation_of_duties":true,"material_change_pauses_approval":true}'::jsonb)
ON CONFLICT DO NOTHING;
