SET search_path TO dispute, public;

INSERT INTO parties(party_id,party_type_code,display_name,external_reference,status_code) VALUES
('20000000-0000-0000-0000-000000000001','customer','Synthetic Customer A','CUST-A','active'),
('20000000-0000-0000-0000-000000000002','merchant','Synthetic Electronics Store','MER-A','active')
ON CONFLICT DO NOTHING;

INSERT INTO cases(case_id,case_reference,title,narrative,case_state_code,processing_side_code,amount,currency_code,customer_name,merchant_name,jurisdiction_code)
VALUES('21000000-0000-0000-0000-000000000001','DSP-LATE-001','Goods not received',
'Customer states the item was not delivered.','specialist_review','issuer',249.99,'USD','Synthetic Customer A','Synthetic Electronics Store','DEMO')
ON CONFLICT DO NOTHING;

INSERT INTO case_parties(case_party_id,case_id,party_id,role_code) VALUES
('21100000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','20000000-0000-0000-0000-000000000001','customer'),
('21100000-0000-0000-0000-000000000002','21000000-0000-0000-0000-000000000001','20000000-0000-0000-0000-000000000002','merchant'),
('21100000-0000-0000-0000-000000000003','21000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000001','issuer')
ON CONFLICT DO NOTHING;

INSERT INTO transactions(transaction_id,external_transaction_ref,merchant_party_id,authorization_code,tokenized_account_ref,transaction_amount,currency_code,transaction_at,posted_at,transaction_status_code)
VALUES('21200000-0000-0000-0000-000000000001','TXN-LATE-001','20000000-0000-0000-0000-000000000002','AUTH-A001','tok_demo_0001',249.99,'USD',now()-interval '20 days',now()-interval '19 days','posted')
ON CONFLICT DO NOTHING;
INSERT INTO case_transactions(case_id,transaction_id,relationship_type_code,disputed_amount)
VALUES('21000000-0000-0000-0000-000000000001','21200000-0000-0000-0000-000000000001','RELATES_TO',249.99)
ON CONFLICT DO NOTHING;

INSERT INTO evidence_items(evidence_item_id,case_id,evidence_type_code,subject_type_code,subject_id,classification_code,status_code) VALUES
('21300000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','customer_statement','case','21000000-0000-0000-0000-000000000001','confidential','open'),
('21300000-0000-0000-0000-000000000002','21000000-0000-0000-0000-000000000001','delivery_proof','transaction','21200000-0000-0000-0000-000000000001','confidential','open')
ON CONFLICT DO NOTHING;

INSERT INTO evidence_versions(evidence_version_id,evidence_item_id,version_no,evidence_source_code,content_text,sha256_hash,valid_at,recorded_at,extractor_version,quality_payload_json) VALUES
('21400000-0000-0000-0000-000000000001','21300000-0000-0000-0000-000000000001',1,'customer','The item was not delivered.','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',now()-interval '18 days',now()-interval '18 days','extractor-1.0','{"completeness":"medium"}'),
('21400000-0000-0000-0000-000000000002','21300000-0000-0000-0000-000000000002',1,'merchant','Carrier status shows delivered to reception.','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',now()-interval '17 days',now()-interval '1 day','extractor-1.0','{"completeness":"high","late_arrival":true}')
ON CONFLICT DO NOTHING;

INSERT INTO assertions(assertion_id,case_id,evidence_version_id,subject_type_code,subject_id,predicate_code,assertion_value_json,valid_from,recorded_at,assertion_status_code,extraction_confidence) VALUES
('21500000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','21400000-0000-0000-0000-000000000001','transaction','21200000-0000-0000-0000-000000000001','delivery_status','{"value":"not_delivered"}',now()-interval '18 days',now()-interval '18 days','open',0.96),
('21500000-0000-0000-0000-000000000002','21000000-0000-0000-0000-000000000001','21400000-0000-0000-0000-000000000002','transaction','21200000-0000-0000-0000-000000000001','delivery_status','{"value":"delivered_to_reception"}',now()-interval '17 days',now()-interval '1 day','open',0.94)
ON CONFLICT DO NOTHING;

INSERT INTO agent_runs(agent_run_id,case_id,agent_id,model_provider,model_name,model_version,prompt_version,policy_version,status_code,started_at,completed_at,token_input_count,token_output_count,cost_amount) VALUES
('21600000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','A09','mock','mock-dispute','1.0','contradiction-1.0','1.0','succeeded',now()-interval '30 minutes',now()-interval '29 minutes',1200,220,0),
('21600000-0000-0000-0000-000000000002','21000000-0000-0000-0000-000000000001','A12','mock','mock-dispute','1.0','material-change-1.0','1.0','succeeded',now()-interval '28 minutes',now()-interval '27 minutes',850,180,0)
ON CONFLICT DO NOTHING;

INSERT INTO agent_outputs(agent_output_id,case_id,agent_run_id,agent_id,output_type_code,output_payload_json,confidence,stale_ind,created_at) VALUES
('21700000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','21600000-0000-0000-0000-000000000001','A09','contradictions','{"items":[{"type":"direct","predicate":"delivery_status","material":true}]}',0.94,false,now()-interval '29 minutes'),
('21700000-0000-0000-0000-000000000002','21000000-0000-0000-0000-000000000001','21600000-0000-0000-0000-000000000002','A12','impact','{"changed_assertions":1,"impacted":["hypothesis","recommendation","approval"]}',0.91,false,now()-interval '27 minutes')
ON CONFLICT DO NOTHING;

INSERT INTO agent_output_evidence(agent_output_id,evidence_version_id,usage_type_code) VALUES
('21700000-0000-0000-0000-000000000001','21400000-0000-0000-0000-000000000001','input'),
('21700000-0000-0000-0000-000000000001','21400000-0000-0000-0000-000000000002','input'),
('21700000-0000-0000-0000-000000000002','21400000-0000-0000-0000-000000000002','changed_source')
ON CONFLICT DO NOTHING;

INSERT INTO assertion_relationships(assertion_relationship_id,source_assertion_id,target_assertion_id,relationship_type_code,severity_code,created_by_agent_output_id) VALUES
('21800000-0000-0000-0000-000000000001','21500000-0000-0000-0000-000000000002','21500000-0000-0000-0000-000000000001','CONTRADICTS','material','21700000-0000-0000-0000-000000000001')
ON CONFLICT DO NOTHING;

INSERT INTO hypotheses(hypothesis_id,case_id,hypothesis_type_code,statement_text,status_code,confidence_band_code,agent_output_id,stale_ind) VALUES
('21900000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','non_delivery','Goods were not delivered to the customer.','open','medium','21700000-0000-0000-0000-000000000001',false),
('21900000-0000-0000-0000-000000000002','21000000-0000-0000-0000-000000000001','delivered_other_recipient','Goods were delivered to reception rather than directly to customer.','open','medium','21700000-0000-0000-0000-000000000001',false)
ON CONFLICT DO NOTHING;

INSERT INTO hypothesis_assertions(hypothesis_id,assertion_id,effect_code,weight) VALUES
('21900000-0000-0000-0000-000000000001','21500000-0000-0000-0000-000000000001','supports',0.85),
('21900000-0000-0000-0000-000000000001','21500000-0000-0000-0000-000000000002','weakens',0.90),
('21900000-0000-0000-0000-000000000002','21500000-0000-0000-0000-000000000002','supports',0.88)
ON CONFLICT DO NOTHING;

INSERT INTO conclusions(conclusion_id,case_id,conclusion_type_code,conclusion_value_json,validity_status_code,agent_output_id,policy_version_id,stale_ind) VALUES
('21a00000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','working_interpretation','{"result":"specialist_review_required"}','current','21700000-0000-0000-0000-000000000002','11000000-0000-0000-0000-000000000001',false)
ON CONFLICT DO NOTHING;

INSERT INTO tasks(task_id,case_id,task_type_code,assigned_role_code,assigned_user_id,status_code,due_at,workflow_reference) VALUES
('21b00000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','specialist_review','dispute_specialist','10000000-0000-0000-0000-000000000011','open',now()+interval '2 days','WF-LATE-001')
ON CONFLICT DO NOTHING;

INSERT INTO approvals(approval_id,case_id,action_type_code,maker_user_id,approver_user_id,status_code,rationale) VALUES
('21c00000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','chargeback_submission','10000000-0000-0000-0000-000000000010','10000000-0000-0000-0000-000000000012','paused','Paused because late merchant evidence materially changed the review package.')
ON CONFLICT DO NOTHING;
INSERT INTO approval_evidence_snapshot(approval_id,evidence_version_id) VALUES
('21c00000-0000-0000-0000-000000000001','21400000-0000-0000-0000-000000000001')
ON CONFLICT DO NOTHING;

INSERT INTO artifact_dependencies(dependency_id,case_id,source_artifact_type,source_artifact_id,target_artifact_type,target_artifact_id,dependency_type_code) VALUES
('21d00000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','evidence_version','21400000-0000-0000-0000-000000000002','approval','21c00000-0000-0000-0000-000000000001','INVALIDATES')
ON CONFLICT DO NOTHING;

INSERT INTO audit_events(audit_event_id,case_id,actor_type_code,actor_id,event_type_code,object_type_code,object_id,details_json) VALUES
('21e00000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','system','seed','EvidenceReceived','evidence_version','21400000-0000-0000-0000-000000000002','{"late":true,"material":true}'),
('21e00000-0000-0000-0000-000000000002','21000000-0000-0000-0000-000000000001','agent','A12','ApprovalPaused','approval','21c00000-0000-0000-0000-000000000001','{"reason":"material_change"}')
ON CONFLICT DO NOTHING;
