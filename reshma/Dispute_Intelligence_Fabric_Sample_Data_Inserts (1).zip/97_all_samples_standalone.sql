-- Combined sample data
BEGIN;

-- ===== 00_sample_master_data.sql =====


-- Synthetic institutions, employees, and external parties.
INSERT INTO parties(party_id,party_type_code,display_name,external_reference,status_code) VALUES
('10000000-0000-0000-0000-000000000001','issuer','Synthetic Issuer Bank','ISS-DEMO-001','active'),
('10000000-0000-0000-0000-000000000002','acquirer','Synthetic Acquirer','ACQ-DEMO-001','active'),
('10000000-0000-0000-0000-000000000003','network','Synthetic Card Network','NET-DEMO-001','active'),
('10000000-0000-0000-0000-000000000010','employee','Alex Investigator','USR-INV-001','active'),
('10000000-0000-0000-0000-000000000011','employee','Sam Specialist','USR-SPL-001','active'),
('10000000-0000-0000-0000-000000000012','employee','Taylor Approver','USR-APR-001','active'),
('10000000-0000-0000-0000-000000000013','employee','Jordan Merchant Specialist','USR-MER-001','active'),
('10000000-0000-0000-0000-000000000014','employee','Casey Auditor','USR-AUD-001','active'),
('10000000-0000-0000-0000-000000000015','courier','Synthetic Delivery Partner','CUR-DEMO-001','active')
ON CONFLICT DO NOTHING;

INSERT INTO policy_versions(policy_version_id,policy_code,version_no,jurisdiction_code,effective_from,policy_payload_json) VALUES
('11000000-0000-0000-0000-000000000001','DISPUTE_ELIGIBILITY','1.0','DEMO',now()-interval '1 year',
 '{"max_age_days":120,"human_final_liability_required":true}'::jsonb),
('11000000-0000-0000-0000-000000000002','MAKER_CHECKER','1.0','DEMO',now()-interval '1 year',
 '{"segregation_of_duties":true,"material_change_pauses_approval":true}'::jsonb)
ON CONFLICT DO NOTHING;


-- ===== 01_late_merchant_evidence.sql =====


INSERT INTO parties(party_id,party_type_code,display_name,external_reference,status_code) VALUES
('20000000-0000-0000-0000-000000000001','customer','Synthetic Customer A','CUST-A','active'),
('20000000-0000-0000-0000-000000000002','merchant','Synthetic Electronics Store','MER-A','active')
ON CONFLICT DO NOTHING;

INSERT INTO cases(case_id,case_reference,title,narrative,case_state_code,processing_side_code,amount,currency_code,customer_name,merchant_name,jurisdiction_code)
VALUES('21000000-0000-0000-0000-000000000001','DSP-LATE-001','Goods not received',
'Customer states the item was not delivered.','specialist_review','issuer',249.99,'USD','Synthetic Customer A','Synthetic Electronics Store','DEMO')
ON CONFLICT DO NOTHING;

INSERT INTO case_parties(case_party_id,case_id,party_id,role_code) VALUES
('21100000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','20000000-0000-0000-0000-000000000001','customer'),
('21100000-0000-0000-0000-000000000002','21000000-0000-0000-0000-000000000001','20000000-0000-0000-0000-000000000002','merchant'),
('21100000-0000-0000-0000-000000000003','21000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000001','issuer')
ON CONFLICT DO NOTHING;

INSERT INTO transactions(transaction_id,external_transaction_ref,merchant_party_id,authorization_code,tokenized_account_ref,transaction_amount,currency_code,transaction_at,posted_at,transaction_status_code)
VALUES('21200000-0000-0000-0000-000000000001','TXN-LATE-001','20000000-0000-0000-0000-000000000002','AUTH-A001','tok_demo_0001',249.99,'USD',now()-interval '20 days',now()-interval '19 days','posted')
ON CONFLICT DO NOTHING;
INSERT INTO case_transactions(case_id,transaction_id,relationship_type_code,disputed_amount)
VALUES('21000000-0000-0000-0000-000000000001','21200000-0000-0000-0000-000000000001','RELATES_TO',249.99)
ON CONFLICT DO NOTHING;

INSERT INTO evidence_items(evidence_item_id,case_id,evidence_type_code,subject_type_code,subject_id,classification_code,status_code) VALUES
('21300000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','customer_statement','case','21000000-0000-0000-0000-000000000001','confidential','open'),
('21300000-0000-0000-0000-000000000002','21000000-0000-0000-0000-000000000001','delivery_proof','transaction','21200000-0000-0000-0000-000000000001','confidential','open')
ON CONFLICT DO NOTHING;

INSERT INTO evidence_versions(evidence_version_id,evidence_item_id,version_no,evidence_source_code,content_text,sha256_hash,valid_at,recorded_at,extractor_version,quality_payload_json) VALUES
('21400000-0000-0000-0000-000000000001','21300000-0000-0000-0000-000000000001',1,'customer','The item was not delivered.','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',now()-interval '18 days',now()-interval '18 days','extractor-1.0','{"completeness":"medium"}'),
('21400000-0000-0000-0000-000000000002','21300000-0000-0000-0000-000000000002',1,'merchant','Carrier status shows delivered to reception.','bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb',now()-interval '17 days',now()-interval '1 day','extractor-1.0','{"completeness":"high","late_arrival":true}')
ON CONFLICT DO NOTHING;

INSERT INTO assertions(assertion_id,case_id,evidence_version_id,subject_type_code,subject_id,predicate_code,assertion_value_json,valid_from,recorded_at,assertion_status_code,extraction_confidence) VALUES
('21500000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','21400000-0000-0000-0000-000000000001','transaction','21200000-0000-0000-0000-000000000001','delivery_status','{"value":"not_delivered"}',now()-interval '18 days',now()-interval '18 days','open',0.96),
('21500000-0000-0000-0000-000000000002','21000000-0000-0000-0000-000000000001','21400000-0000-0000-0000-000000000002','transaction','21200000-0000-0000-0000-000000000001','delivery_status','{"value":"delivered_to_reception"}',now()-interval '17 days',now()-interval '1 day','open',0.94)
ON CONFLICT DO NOTHING;

INSERT INTO agent_runs(agent_run_id,case_id,agent_id,model_provider,model_name,model_version,prompt_version,policy_version,status_code,started_at,completed_at,token_input_count,token_output_count,cost_amount) VALUES
('21600000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','A09','mock','mock-dispute','1.0','contradiction-1.0','1.0','succeeded',now()-interval '30 minutes',now()-interval '29 minutes',1200,220,0),
('21600000-0000-0000-0000-000000000002','21000000-0000-0000-0000-000000000001','A12','mock','mock-dispute','1.0','material-change-1.0','1.0','succeeded',now()-interval '28 minutes',now()-interval '27 minutes',850,180,0)
ON CONFLICT DO NOTHING;

INSERT INTO agent_outputs(agent_output_id,case_id,agent_run_id,agent_id,output_type_code,output_payload_json,confidence,stale_ind,created_at) VALUES
('21700000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','21600000-0000-0000-0000-000000000001','A09','contradictions','{"items":[{"type":"direct","predicate":"delivery_status","material":true}]}',0.94,false,now()-interval '29 minutes'),
('21700000-0000-0000-0000-000000000002','21000000-0000-0000-0000-000000000001','21600000-0000-0000-0000-000000000002','A12','impact','{"changed_assertions":1,"impacted":["hypothesis","recommendation","approval"]}',0.91,false,now()-interval '27 minutes')
ON CONFLICT DO NOTHING;

INSERT INTO agent_output_evidence(agent_output_id,evidence_version_id,usage_type_code) VALUES
('21700000-0000-0000-0000-000000000001','21400000-0000-0000-0000-000000000001','input'),
('21700000-0000-0000-0000-000000000001','21400000-0000-0000-0000-000000000002','input'),
('21700000-0000-0000-0000-000000000002','21400000-0000-0000-0000-000000000002','changed_source')
ON CONFLICT DO NOTHING;

INSERT INTO assertion_relationships(assertion_relationship_id,source_assertion_id,target_assertion_id,relationship_type_code,severity_code,created_by_agent_output_id) VALUES
('21800000-0000-0000-0000-000000000001','21500000-0000-0000-0000-000000000002','21500000-0000-0000-0000-000000000001','CONTRADICTS','material','21700000-0000-0000-0000-000000000001')
ON CONFLICT DO NOTHING;

INSERT INTO hypotheses(hypothesis_id,case_id,hypothesis_type_code,statement_text,status_code,confidence_band_code,agent_output_id,stale_ind) VALUES
('21900000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','non_delivery','Goods were not delivered to the customer.','open','medium','21700000-0000-0000-0000-000000000001',false),
('21900000-0000-0000-0000-000000000002','21000000-0000-0000-0000-000000000001','delivered_other_recipient','Goods were delivered to reception rather than directly to customer.','open','medium','21700000-0000-0000-0000-000000000001',false)
ON CONFLICT DO NOTHING;

INSERT INTO hypothesis_assertions(hypothesis_id,assertion_id,effect_code,weight) VALUES
('21900000-0000-0000-0000-000000000001','21500000-0000-0000-0000-000000000001','supports',0.85),
('21900000-0000-0000-0000-000000000001','21500000-0000-0000-0000-000000000002','weakens',0.90),
('21900000-0000-0000-0000-000000000002','21500000-0000-0000-0000-000000000002','supports',0.88)
ON CONFLICT DO NOTHING;

INSERT INTO conclusions(conclusion_id,case_id,conclusion_type_code,conclusion_value_json,validity_status_code,agent_output_id,policy_version_id,stale_ind) VALUES
('21a00000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','working_interpretation','{"result":"specialist_review_required"}','current','21700000-0000-0000-0000-000000000002','11000000-0000-0000-0000-000000000001',false)
ON CONFLICT DO NOTHING;

INSERT INTO tasks(task_id,case_id,task_type_code,assigned_role_code,assigned_user_id,status_code,due_at,workflow_reference) VALUES
('21b00000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','specialist_review','dispute_specialist','10000000-0000-0000-0000-000000000011','open',now()+interval '2 days','WF-LATE-001')
ON CONFLICT DO NOTHING;

INSERT INTO approvals(approval_id,case_id,action_type_code,maker_user_id,approver_user_id,status_code,rationale) VALUES
('21c00000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','chargeback_submission','10000000-0000-0000-0000-000000000010','10000000-0000-0000-0000-000000000012','paused','Paused because late merchant evidence materially changed the review package.')
ON CONFLICT DO NOTHING;
INSERT INTO approval_evidence_snapshot(approval_id,evidence_version_id) VALUES
('21c00000-0000-0000-0000-000000000001','21400000-0000-0000-0000-000000000001')
ON CONFLICT DO NOTHING;

INSERT INTO artifact_dependencies(dependency_id,case_id,source_artifact_type,source_artifact_id,target_artifact_type,target_artifact_id,dependency_type_code) VALUES
('21d00000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','evidence_version','21400000-0000-0000-0000-000000000002','approval','21c00000-0000-0000-0000-000000000001','INVALIDATES')
ON CONFLICT DO NOTHING;

INSERT INTO audit_events(audit_event_id,case_id,actor_type_code,actor_id,event_type_code,object_type_code,object_id,details_json) VALUES
('21e00000-0000-0000-0000-000000000001','21000000-0000-0000-0000-000000000001','system','seed','EvidenceReceived','evidence_version','21400000-0000-0000-0000-000000000002','{"late":true,"material":true}'),
('21e00000-0000-0000-0000-000000000002','21000000-0000-0000-0000-000000000001','agent','A12','ApprovalPaused','approval','21c00000-0000-0000-0000-000000000001','{"reason":"material_change"}')
ON CONFLICT DO NOTHING;


-- ===== 02_unauthorized_transaction.sql =====

INSERT INTO parties(party_id,party_type_code,display_name,external_reference,status_code) VALUES
('30000000-0000-0000-0000-000000000001','customer','Synthetic Customer B','CUST-B','active'),
('30000000-0000-0000-0000-000000000002','merchant','Synthetic Online Marketplace','MER-B','active') ON CONFLICT DO NOTHING;
INSERT INTO cases(case_id,case_reference,title,narrative,case_state_code,processing_side_code,amount,currency_code,customer_name,merchant_name,jurisdiction_code) VALUES
('31000000-0000-0000-0000-000000000001','DSP-UNAUTH-001','Unauthorized transaction','Customer states the purchase was not authorized.','interpretation_ready','issuer',89.50,'USD','Synthetic Customer B','Synthetic Online Marketplace','DEMO') ON CONFLICT DO NOTHING;
INSERT INTO case_parties(case_party_id,case_id,party_id,role_code) VALUES
('31100000-0000-0000-0000-000000000001','31000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001','customer'),
('31100000-0000-0000-0000-000000000002','31000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000002','merchant') ON CONFLICT DO NOTHING;
INSERT INTO transactions(transaction_id,external_transaction_ref,merchant_party_id,authorization_code,tokenized_account_ref,transaction_amount,currency_code,transaction_at,posted_at,transaction_status_code) VALUES
('31200000-0000-0000-0000-000000000001','TXN-UNAUTH-001','30000000-0000-0000-0000-000000000002','AUTH-B001','tok_demo_0002',89.50,'USD',now()-interval '12 days',now()-interval '11 days','posted') ON CONFLICT DO NOTHING;
INSERT INTO case_transactions(case_id,transaction_id,relationship_type_code,disputed_amount) VALUES
('31000000-0000-0000-0000-000000000001','31200000-0000-0000-0000-000000000001','RELATES_TO',89.50) ON CONFLICT DO NOTHING;
INSERT INTO evidence_items(evidence_item_id,case_id,evidence_type_code,subject_type_code,subject_id,classification_code,status_code) VALUES
('31300000-0000-0000-0000-000000000001','31000000-0000-0000-0000-000000000001','customer_statement','case','31000000-0000-0000-0000-000000000001','confidential','open'),
('31300000-0000-0000-0000-000000000002','31000000-0000-0000-0000-000000000001','authentication_event','transaction','31200000-0000-0000-0000-000000000001','restricted','open') ON CONFLICT DO NOTHING;
INSERT INTO evidence_versions(evidence_version_id,evidence_item_id,version_no,evidence_source_code,content_text,sha256_hash,valid_at) VALUES
('31400000-0000-0000-0000-000000000001','31300000-0000-0000-0000-000000000001',1,'customer','I did not authorize this purchase.','cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc',now()-interval '10 days'),
('31400000-0000-0000-0000-000000000002','31300000-0000-0000-0000-000000000002',1,'authentication_system','3DS challenge completed for the transaction.','dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd',now()-interval '12 days') ON CONFLICT DO NOTHING;
INSERT INTO case_events(case_event_id,case_id,event_type_code,event_at,evidence_version_id,event_payload_json,certainty_code) VALUES
('31500000-0000-0000-0000-000000000001','31000000-0000-0000-0000-000000000001','3ds_challenge_completed',now()-interval '12 days','31400000-0000-0000-0000-000000000002','{"result":"success"}','observed') ON CONFLICT DO NOTHING;
INSERT INTO tasks(task_id,case_id,task_type_code,assigned_role_code,assigned_user_id,status_code,due_at,workflow_reference) VALUES
('31600000-0000-0000-0000-000000000001','31000000-0000-0000-0000-000000000001','specialist_review','fraud_specialist','10000000-0000-0000-0000-000000000011','open',now()+interval '1 day','WF-UNAUTH-001') ON CONFLICT DO NOTHING;
INSERT INTO audit_events(audit_event_id,case_id,actor_type_code,actor_id,event_type_code,details_json) VALUES
('31700000-0000-0000-0000-000000000001','31000000-0000-0000-0000-000000000001','system','seed','CaseCreated','{"synthetic":true}') ON CONFLICT DO NOTHING;


-- ===== 03_duplicate_billing.sql =====

INSERT INTO parties(party_id,party_type_code,display_name,external_reference,status_code) VALUES
('40000000-0000-0000-0000-000000000001','customer','Synthetic Customer C','CUST-C','active'),
('40000000-0000-0000-0000-000000000002','merchant','Synthetic Subscription Service','MER-C','active') ON CONFLICT DO NOTHING;
INSERT INTO cases(case_id,case_reference,title,narrative,case_state_code,processing_side_code,amount,currency_code,customer_name,merchant_name,jurisdiction_code) VALUES
('41000000-0000-0000-0000-000000000001','DSP-DUP-001','Duplicate billing','Customer reports two charges for one subscription.','gathering_evidence','issuer',39.98,'USD','Synthetic Customer C','Synthetic Subscription Service','DEMO') ON CONFLICT DO NOTHING;
INSERT INTO transactions(transaction_id,external_transaction_ref,merchant_party_id,authorization_code,tokenized_account_ref,transaction_amount,currency_code,transaction_at,posted_at,transaction_status_code) VALUES
('41200000-0000-0000-0000-000000000001','TXN-DUP-001-A','40000000-0000-0000-0000-000000000002','AUTH-C001','tok_demo_0003',19.99,'USD',now()-interval '8 days',now()-interval '7 days','posted'),
('41200000-0000-0000-0000-000000000002','TXN-DUP-001-B','40000000-0000-0000-0000-000000000002','AUTH-C002','tok_demo_0003',19.99,'USD',now()-interval '8 days'+interval '2 minutes',now()-interval '7 days','posted') ON CONFLICT DO NOTHING;
INSERT INTO case_transactions(case_id,transaction_id,relationship_type_code,disputed_amount) VALUES
('41000000-0000-0000-0000-000000000001','41200000-0000-0000-0000-000000000001','RELATES_TO',19.99),
('41000000-0000-0000-0000-000000000001','41200000-0000-0000-0000-000000000002','DUPLICATES',19.99) ON CONFLICT DO NOTHING;
INSERT INTO evidence_items(evidence_item_id,case_id,evidence_type_code,subject_type_code,subject_id,classification_code,status_code) VALUES
('41300000-0000-0000-0000-000000000001','41000000-0000-0000-0000-000000000001','transaction_event','case','41000000-0000-0000-0000-000000000001','restricted','open') ON CONFLICT DO NOTHING;
INSERT INTO evidence_versions(evidence_version_id,evidence_item_id,version_no,evidence_source_code,content_text,sha256_hash,valid_at) VALUES
('41400000-0000-0000-0000-000000000001','41300000-0000-0000-0000-000000000001',1,'core_card_system','Two equal-value transactions posted within two minutes.','eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee',now()-interval '8 days') ON CONFLICT DO NOTHING;
INSERT INTO audit_events(audit_event_id,case_id,actor_type_code,actor_id,event_type_code,details_json) VALUES
('41700000-0000-0000-0000-000000000001','41000000-0000-0000-0000-000000000001','system','seed','CaseCreated','{"synthetic":true,"scenario":"duplicate_billing"}') ON CONFLICT DO NOTHING;


-- ===== 04_refund_not_processed.sql =====

INSERT INTO parties(party_id,party_type_code,display_name,external_reference,status_code) VALUES
('50000000-0000-0000-0000-000000000001','customer','Synthetic Customer D','CUST-D','active'),
('50000000-0000-0000-0000-000000000002','merchant','Synthetic Travel Merchant','MER-D','active') ON CONFLICT DO NOTHING;
INSERT INTO cases(case_id,case_reference,title,narrative,case_state_code,processing_side_code,amount,currency_code,customer_name,merchant_name,jurisdiction_code) VALUES
('51000000-0000-0000-0000-000000000001','DSP-REFUND-001','Refund not processed','Customer states an agreed refund is not visible.','awaiting_evidence','issuer',450.00,'USD','Synthetic Customer D','Synthetic Travel Merchant','DEMO') ON CONFLICT DO NOTHING;
INSERT INTO evidence_items(evidence_item_id,case_id,evidence_type_code,subject_type_code,subject_id,classification_code,status_code) VALUES
('51300000-0000-0000-0000-000000000001','51000000-0000-0000-0000-000000000001','refund_record','case','51000000-0000-0000-0000-000000000001','confidential','open'),
('51300000-0000-0000-0000-000000000002','51000000-0000-0000-0000-000000000001','reconciliation_record','case','51000000-0000-0000-0000-000000000001','restricted','open') ON CONFLICT DO NOTHING;
INSERT INTO evidence_versions(evidence_version_id,evidence_item_id,version_no,evidence_source_code,content_text,sha256_hash,valid_at) VALUES
('51400000-0000-0000-0000-000000000001','51300000-0000-0000-0000-000000000001',1,'merchant','Merchant refund reference RF-DEMO-001 created.','ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',now()-interval '5 days'),
('51400000-0000-0000-0000-000000000002','51300000-0000-0000-0000-000000000002',1,'reconciliation_system','No matching refund posting found as of reconciliation run.','1111111111111111111111111111111111111111111111111111111111111111',now()-interval '1 day') ON CONFLICT DO NOTHING;
INSERT INTO tasks(task_id,case_id,task_type_code,assigned_role_code,status_code,due_at,workflow_reference) VALUES
('51600000-0000-0000-0000-000000000001','51000000-0000-0000-0000-000000000001','request_acquirer_refund_status','investigator','open',now()+interval '1 day','WF-REFUND-001') ON CONFLICT DO NOTHING;
INSERT INTO audit_events(audit_event_id,case_id,actor_type_code,actor_id,event_type_code,details_json) VALUES
('51700000-0000-0000-0000-000000000001','51000000-0000-0000-0000-000000000001','system','seed','CaseCreated','{"synthetic":true,"scenario":"refund_not_processed"}') ON CONFLICT DO NOTHING;


-- ===== 05_merchant_representment.sql =====

INSERT INTO parties(party_id,party_type_code,display_name,external_reference,status_code) VALUES
('60000000-0000-0000-0000-000000000001','customer','Synthetic Customer E','CUST-E','active'),
('60000000-0000-0000-0000-000000000002','merchant','Synthetic Furniture Merchant','MER-E','active') ON CONFLICT DO NOTHING;
INSERT INTO cases(case_id,case_reference,title,narrative,case_state_code,processing_side_code,amount,currency_code,customer_name,merchant_name,jurisdiction_code) VALUES
('61000000-0000-0000-0000-000000000001','DSP-REP-001','Merchant representment','Merchant contests a non-delivery chargeback with delivery and correspondence evidence.','approval_pending','merchant',799.00,'USD','Synthetic Customer E','Synthetic Furniture Merchant','DEMO') ON CONFLICT DO NOTHING;
INSERT INTO case_parties(case_party_id,case_id,party_id,role_code) VALUES
('61100000-0000-0000-0000-000000000001','61000000-0000-0000-0000-000000000001','60000000-0000-0000-0000-000000000001','customer'),
('61100000-0000-0000-0000-000000000002','61000000-0000-0000-0000-000000000001','60000000-0000-0000-0000-000000000002','merchant'),
('61100000-0000-0000-0000-000000000003','61000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000002','acquirer') ON CONFLICT DO NOTHING;
INSERT INTO evidence_items(evidence_item_id,case_id,evidence_type_code,subject_type_code,subject_id,classification_code,status_code) VALUES
('61300000-0000-0000-0000-000000000001','61000000-0000-0000-0000-000000000001','delivery_proof','case','61000000-0000-0000-0000-000000000001','confidential','open'),
('61300000-0000-0000-0000-000000000002','61000000-0000-0000-0000-000000000001','correspondence','case','61000000-0000-0000-0000-000000000001','confidential','open') ON CONFLICT DO NOTHING;
INSERT INTO evidence_versions(evidence_version_id,evidence_item_id,version_no,evidence_source_code,content_text,sha256_hash,valid_at) VALUES
('61400000-0000-0000-0000-000000000001','61300000-0000-0000-0000-000000000001',1,'merchant','Signed delivery confirmation for order ORD-DEMO-E.','2222222222222222222222222222222222222222222222222222222222222222',now()-interval '25 days'),
('61400000-0000-0000-0000-000000000002','61300000-0000-0000-0000-000000000002',1,'merchant','Customer correspondence acknowledges receipt and requests later return.','3333333333333333333333333333333333333333333333333333333333333333',now()-interval '24 days') ON CONFLICT DO NOTHING;
INSERT INTO approvals(approval_id,case_id,action_type_code,maker_user_id,approver_user_id,status_code,rationale,decided_at) VALUES
('61c00000-0000-0000-0000-000000000001','61000000-0000-0000-0000-000000000001','representment_submission','10000000-0000-0000-0000-000000000013','10000000-0000-0000-0000-000000000012','approved','Representment evidence package reviewed and approved.',now()-interval '1 hour') ON CONFLICT DO NOTHING;
INSERT INTO approval_evidence_snapshot(approval_id,evidence_version_id) VALUES
('61c00000-0000-0000-0000-000000000001','61400000-0000-0000-0000-000000000001'),
('61c00000-0000-0000-0000-000000000001','61400000-0000-0000-0000-000000000002') ON CONFLICT DO NOTHING;
INSERT INTO actions(action_id,case_id,approval_id,action_type_code,idempotency_key,status_code,external_reference,result_payload_json) VALUES
('61d00000-0000-0000-0000-000000000001','61000000-0000-0000-0000-000000000001','61c00000-0000-0000-0000-000000000001','representment_submission','DSP-REP-001:representment:1','submitted','NET-REP-DEMO-001','{"acknowledged":true}') ON CONFLICT DO NOTHING;
INSERT INTO action_attempts(action_attempt_id,action_id,attempt_number,request_payload_hash,started_at,completed_at,outcome_code,external_reference,response_payload_json) VALUES
('61e00000-0000-0000-0000-000000000001','61d00000-0000-0000-0000-000000000001',1,'4444444444444444444444444444444444444444444444444444444444444444',now()-interval '50 minutes',now()-interval '49 minutes','accepted','NET-REP-DEMO-001','{"network_status":"received"}') ON CONFLICT DO NOTHING;
INSERT INTO integration_events(integration_event_id,case_id,event_type_code,schema_version,source_system_code,correlation_id,idempotency_key,payload_json,occurred_at,processing_status_code) VALUES
('61f00000-0000-0000-0000-000000000001','61000000-0000-0000-0000-000000000001','RepresentmentSubmitted','1.0','action_gateway','61f00000-0000-0000-0000-000000000010','DSP-REP-001:representment:1','{"external_reference":"NET-REP-DEMO-001"}',now()-interval '50 minutes','succeeded') ON CONFLICT DO NOTHING;
INSERT INTO audit_events(audit_event_id,case_id,actor_type_code,actor_id,event_type_code,object_type_code,object_id,details_json) VALUES
('61a00000-0000-0000-0000-000000000001','61000000-0000-0000-0000-000000000001','human','USR-APR-001','ApprovalDecided','approval','61c00000-0000-0000-0000-000000000001','{"status":"approved"}'),
('61a00000-0000-0000-0000-000000000002','61000000-0000-0000-0000-000000000001','service','action_gateway','ActionSubmitted','action','61d00000-0000-0000-0000-000000000001','{"external_reference":"NET-REP-DEMO-001"}') ON CONFLICT DO NOTHING;

COMMIT;
